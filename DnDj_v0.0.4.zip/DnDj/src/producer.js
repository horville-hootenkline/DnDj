import ModuleSettings from "./linerNotes.js";
import {debug, report} from './engineer.js';
import DnDjRadio from "./radio.js";
import * as engineer from './engineer.js';
import * as albumCover from './albumCover.js'
import * as mixer from './mixer.js'
import DnDj from "./dndj.js";

//--//--//--//--//--//--//
// !--   init hook  --! //
//--//--//--//--//--//--//
//
Hooks.once('init', () => {
	console.log('[(( DNDJ init ))] "Music can name the unnameable and communicate the unknowable.” - Leonard Bernstein');
	ModuleSettings.register();
	engineer.preloadTemplates();
	engineer.registerHandlebarsHelpers();
});

export var _isLaunch = true;
export function set_isLaunch(value) {
	_isLaunch = value;
}

//--//--//--//--//--//--//
// !--  ready hook  --! //
//--//--//--//--//--//--//
//
Hooks.once("ready", () => {
	//
	var pettibone = 'DnDj ready';
	//
	game.dndjRadio = new DnDjRadio();
	engineer.tuneTheRadio();
	//
	if (!game.dndj && game.user.isGM) {
		game.settings.set("DnDj", "isLaunch", true);

		$('input[name="paSlider"]').parent().hide();
		$('input[name="globalPlaylistVolume"]').parent().show();

		var playlists = game.playlists.entities;
		if (typeof game.user.data.flags.DnDj.masterFader == 'undefined' || typeof game.user.data.flags.DnDj.fade == 'undefined' || typeof game.user.data.flags.DnDj.setlists == 'undefined') {
			// launching for first time - creating system flags
			if (debug(0)){console.log(report(pettibone, '... 1st TIME'))};
			game.user.setFlag('DnDj', 'masterFader', {is: true, volume: 1})
			game.user.setFlag('DnDj', 'fade', 4),
			game.user.setFlag('DnDj', 'setlists', []),
			engineer.flagCheck(playlists, true);
		}
		if (game.settings.get("DnDj", "rehaudio")) {
			engineer.removeFlags(playlists, true);
		} else {
			engineer.flagCheck(playlists, true);
		}
		// reset the reset button.
		if (game.settings.get("DnDj", "rehaudio")) {
			game.settings.set("DnDj", "rehaudio", false)
		};
		//
		//game.dndj = new DnDj();
		//
		//if (game.user.data.flags.DnDj.setlists.length != 0) {
		//	game.dndj.status.isSetlist = true;
		//}
	}
});

//--//--//--//--//--//--//--//--//--//--//--//
// !--  render playlist directory hook  --! //
//--//--//--//--//--//--//--//--//--//--//--//
//
Hooks.on("renderPlaylistDirectory", (app, html, data) => {
	if (game.user.isGM) {
		const dndjButton = $(albumCover.button);
	//
	// GM BUTTON
	//
		html.find(".directory-footer").append(dndjButton);
		dndjButton.click((ev) => {
			if (!game.dndj) {
			game.dndj = new DnDj();
			}
			if (game.user.data.flags.DnDj.setlists.length != 0) {
				game.dndj.status.isSetlist = true;
			}
			if (!game.dndj.rendered) {
			engineer.turnItOnAgain();
			mixer.countingOutTime();
			}
		});
	}
	//
	// PERSONAL SLIDER
	//
	const dndjPersonalSlider = $(albumCover.paSlider(game.user.data.flags.DnDj.personalSlider));
	html.find('input[name="globalPlaylistVolume"]').parent().after(dndjPersonalSlider);
	$('input[name="paSlider"]').val($('input[name="globalPlaylistVolume"]').val());
	$('input[name="paSlider"]').parent().hide();
	if (!_isLaunch) {
		if (game.settings.get("DnDj", "gpvHide")) {
            $('input[name="globalPlaylistVolume"]').parent().hide()
        }
		$('input[name="paSlider"]').parent().show();
		}
	$(document).on('change', '#paSlider', function() {
		game.user.setFlag('DnDj', 'personalSlider', parseFloat($(event.target)[0].value));
		game.dndjRadio.volumes.paInput = parseFloat($(event.target)[0].value);
		game.dndjRadio.volumes.paVolume = AudioHelper.inputToVolume(game.dndjRadio.volumes.paInput,2);
		if (game.user.isGM) {
			game.dndj.volumes.paInput = parseFloat($(event.target)[0].value);
			game.dndj.volumes.paVolume = AudioHelper.inputToVolume(game.dndj.volumes.paInput,2);
			var inTheMix = game.dndj.chart.filter(mf => mf.inTheMix == true);
                for (const chartEntry of inTheMix) {
                    mixer.bruteForceVolume(chartEntry, chartEntry.volumeVol)    
                }
		} else {
			for (const entry of game.dndjRadio.broadcast) {
				game.audio.sounds[entry.path].howl.volume(entry.volume * game.dndjRadio.volumes.paVolume);
			}
		}
	});	

});

//--//--//--//--//--//--//--//--//
// !--   render dndj hook   --! //
//--//--//--//--//--//--//--//--//
//
Hooks.on("closeDnDj", function (context, data) {
	if (!context.status.isLaunch){
		context.status.addPaused = game.settings.get("DnDj", "pauseAddClosed")
	} else {
		context.status.addPaused = false
	}
})

//--//--//--//--//--//--//--//--//
// !--   close dndj hook    --! //
//--//--//--//--//--//--//--//--//
//
Hooks.on("renderDnDj", function (context, data) {
	if (!context.status.isLaunch){
		context.status.addPaused = game.settings.get("DnDj", "pauseAddOpen")
	} else {
		context.status.addPaused = false
	}
})

//--//--//--//--//--//--//--//--//--//--//--//
// !--   preupdate playlistsound hook   --! //
//--//--//--//--//--//--//--//--//--//--//--//
//
Hooks.on("preUpdatePlaylistSound", function (data, updateData, context) {
	//
	var pettibone = 'preupdatePlaylistSound.hook';
	// adding chart entry if there isn't one and it's not launch
	if (!_isLaunch) {
		if (!(game.dndj.chart.some(e => e.id == context._id))) {
			game.dndj.chart.push(engineer.addChartEntry(data, updateData, false, false));
		}
		var chartEntry = game.dndj.chart.find(i => i.id == context._id);
		var whatChanged = Object.keys(context)[0];
		//
		if (whatChanged == 'playing' && context.playing) {
			if (!game.dndj.status.isLaunch) {
				var _paused = chartEntry.paused;
			} else {
				var _paused = false;
			}
			if (game.dndj.status.addPaused || _paused) {
				updateData.volume = 0;
				context.volume = 0;
			}
			game.dndj.status.human = false;
			return;
		}
		//
		if (whatChanged == 'playing' && !context.playing) {
			if (chartEntry.loop && !game.dndj.status.human) {
				return false;
			}
			updateData.volume = chartEntry.volumeVol * game.dndj.volumes.maVolume * game.dndjRadio.volumes.paVolume;
			context.volume = chartEntry.volumeVol * game.dndj.volumes.maVolume * game.dndjRadio.volumes.paVolume;
			context.repeat = chartEntry.loop;
			game.dndj.status.human = false;
			return;
		}
		//
		if (whatChanged == 'repeat' && updateData.playing) {
			return false;
		}
		//
		if (whatChanged == 'volume') {
			return false;
		}
	}
});

//--//--//--//--//--//--//--//--//--//--//
// !--  update playlistsound hook  --! //
//--//--//--//--//--//--//--//--//--//--//
//
Hooks.on("updatePlaylistSound", function (context, parentId, data, updateData) {
	//
	//console.log(data); console.log(parentId);
	if (data.upls == false) {
		return;
	}
	engineer.uplsFunction(data, context, parentId)

});

var plUpArray = [];

//--//--//--//--//--//--//--//--//--//
// !-- preupdate playlist hook  --! //
//--//--//--//--//--//--//--//--//--//
//
Hooks.on("preUpdatePlaylist", async function (context, parentId, data, updateData, options) {
	//
	//console.log(context); console.log(data); console.log(plUpArray) ;console.log(updateData);
	if (!_isLaunch && data.diff && game.user.isGM) {
		if (typeof parentId.sounds != 'undefined'){
			var _list = game.playlists.entities.find(ent => ent._id == parentId._id)
			for (const that of parentId.sounds) {
				if (that.playing != _list.sounds.find(ent => ent._id == that._id).playing || !parentId.playing) {
					if (!(game.dndj.chart.some(e => e.id == that._id))) {
						game.dndj.chart.push(engineer.addChartEntry(_list, that, false, false));
					}
					//var data = ({_id: that._id, playing: that.playing});
					plUpArray.push({playing: that.playing, _id: that._id});
				}
			}
		}
	}


})

//--//--//--//--//--//--//--//--//
// !-- update playlist hook --! //
//--//--//--//--//--//--//--//--//
//
Hooks.on("updatePlaylist", async function (context, parentId, data, updateData) {
	//
	if (game.user.isGM) {
		// ! if (debug(2)){console.log(report(pettibone, context.name))};
		// ! console.log(context); console.log(data); console.log(plUpArray) ;console.log(updateData); console.log(plUpArray)
		if (_isLaunch == false) {
			for (const _data of plUpArray) {
				engineer.uplsFunction (_data, context, parentId.sounds.find(ent => ent._id == _data._id))
			}
			plUpArray = [];
		}
	}
})
