
//--//--//--//--//--//--//--//--//--//--//--//--//--//--//
//   * ~ * ~ * ~ *   RADIO APPLICATION   * ~ * ~ * ~ *  //
//--//--//--//--//--//--//--//--//--//--//--//--//--//--//

export default class DnDjRadio extends Application {
    
    volumes = {
        paInput: .909,
        paVolume: .909
    };
    broadcast = [];
    status = {
        debug: game.settings.get("DnDj", "debug"),
        debug_level: parseInt(game.settings.get("DnDj", "debug_level"),10),
        playArray: []
    };
    pauseAdd = {
            open: game.settings.get("DnDj", "pauseAddOpen"),
            closed: game.settings.get("DnDj", "pauseAddClosed")
    };
    intervalLog = {
        paInput: null
    }
  
    static get defaultOptions() {
      return mergeObject(super.defaultOptions, {
        id: "dndjRadio",
        title: "dndjRadio",
      });
    }
}