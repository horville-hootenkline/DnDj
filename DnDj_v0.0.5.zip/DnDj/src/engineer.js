//import * as inAt from './no1.js';
//import {debug, report} from './no1.js';
import * as producer from './producer.js';
import DnDjRadio from "./radio.js";
import * as mixer from './mixer.js';
import * as listener from './listener.js';

export function preloadTemplates() {
    let templates = [
		"templates/track.html"
    ];

    templates = templates.map(t => `modules/DnDj/${t}`);
    loadTemplates(templates);
}

export function registerHandlebarsHelpers() {
Handlebars.registerHelper('if_eq', function(a, b, opts) {
    if (a == b) {
        return opts.fn(this);
    } else {
        return opts.inverse(this);
    }
});
}

const sleep = (milliseconds) => {
    return new Promise(resolve => setTimeout(resolve, milliseconds))
}

//--//--//--//--//--//--//--//--//
// !-- time format function --! //
//--//--//--//--//--//--//--//--//
//
export function timeFormat(time) {
    var _date = new Date(0);
    _date.setSeconds(time);
    if (_date.toISOString().substr(14, 1) == 0) {
        var mmss = _date.toISOString().substr(15, 4)
    } else {
        var mmss = _date.toISOString().substr(14, 5)
    };
    if (_date.toISOString().substr(11, 1) == 0) {
        var hhmmss = _date.toISOString().substr(12, 7);
    } else {
        var hhmmss = _date.toISOString().substr(11, 8);
    }
    var hh = _date.toISOString().substr(12, 2);
    if (hh == "0") {hh = null};
    var fadeTime = _date.toISOString().substr(15, 4).replace(':','.');
    return {hh,mmss,hhmmss,fadeTime};
}

//--//--//--//--//--//--//--//--//--//--//
// !--  turn it on again function   --! //
//--//--//--//--//--//--//--//--//--//--//
//
export async function turnItOnAgain() {
    await game.dndj.render(true); 
    await sleep(150);
    //$("#fade").val(game.user.data.flags.DnDj.fade).attr("selected","selected");
}

//--//--//--//--//--//--//--//--//--//
// !--  tune the radiofunction  --! //
//--//--//--//--//--//--//--//--//--//
//
export function tuneTheRadio() {
		game.user.setFlag('DnDj', 'personalSlider', .909);
}

//--//--//--//--//--//--//--//--//
// !--  flag array function  --! //
//--//--//--//--//--//--//--//--//
//
export function flagArray(sound) {
// 
// flag array for when a track has no chart entry.
//
    var archive = {
        is: true,
        name: sound.name,
        volume: sound.volume,
        slider: AudioHelper.volumeToInput(sound.volume),
        itm: sound.playing,
        paused: false,
        mute: false,
        elapsed: 0,
        duration: 0,
        pinned: false,
        playing: sound.playing
    };
    return archive;
}

//--//--//--//--//--//--//--//
// !--  debug function  --! //
//--//--//--//--//--//--//--//
//
export function debug(level) {
    if (game.dndjRadio.status.debug_level >= level) {
        return true
    } else {
        return false
    }
}

//--//--//--//--//--//--//--//
// !-- report function  --! //
//--//--//--//--//--//--//--//
//
export function report(jeanine, oneTwo, treehorn) {
    var standout = '[(( '+ jeanine +' ))] ';
        if (typeof oneTwo != 'string') {
            return oneTwo;
        } else {
            return standout + oneTwo
        }
}

//--//--//--//--//--//--//--//--//--//
// !--  remove flags function   --! //
//--//--//--//--//--//--//--//--//--//
//
export async function removeFlags(playlistsPlaying, segue) {
    var pettibone = 'removeFlags';
    if (debug(1)){console.log(report(pettibone, '- - - - - - - - '))};
    for (let i = 0; i < playlistsPlaying.length; i++){
        let soundsPlaying = playlistsPlaying[i].sounds;
        for (let e = 0; e < soundsPlaying.length; e++){	
            var _playlist = playlistsPlaying[i]; var _sound = soundsPlaying[e]; var eyeD = soundsPlaying[e]._id;
            if (typeof game.user.data.flags.DnDj[eyeD] != 'undefined') {
                await game.user.unsetFlag('DnDj', eyeD).then(() => {
                    if (debug(0)){console.log(report(pettibone, eyeD + ' flag removed (' + _sound.name + '/' + _playlist.name + ')'))};
                });
            }
        }
    }
    if (debug(2)){console.log(report(pettibone, 'done'))};
    if (segue) {flagCheck(playlistsPlaying, segue)};
}
    
//--//--//--//--//--//--//--//--//
// !-- flag check function  --! //
//--//--//--//--//--//--//--//--//
//
export async function flagCheck(playlistsPlaying, segue) {
    var pettibone = 'DnDj flagCheck';
    var flags = 0;
    for (let i = 0; i < playlistsPlaying.length; i++){
        let soundsPlaying = playlistsPlaying[i].sounds;
        for (let e = 0; e < soundsPlaying.length; e++){
            var _playlist = playlistsPlaying[i]; var _sound = soundsPlaying[e]; var eyeD = soundsPlaying[e]._id;
            if (typeof game.user.data.flags.DnDj[eyeD] != 'undefined') {
                flags++;
            }  
        }
    }
    if (debug(0)){console.log(report(pettibone, flags + ' flags found'))};
}
    
//--//--//--//--//--//--//--//--//--//--//
// !--  brute force flags function  --! //
//--//--//--//--//--//--//--//--//--//--//
//
export async function bruteForceFlags(location, eyeD, data, noChart) {
// if the request isn't a sound flag -
    var pettibone = 'bfFlags';
    if (['fade', 'masterFader', 'playAddOpen', 'setlists'].includes(eyeD)) {
        await location.unsetFlag('DnDj', eyeD);
        await location.setFlag('DnDj', eyeD, data)
        //
        if (typeof game.user.data.flags.DnDj[eyeD] == 'undefined') {var result = 'empty'} else {var result = game.user.data.flags.DnDj[eyeD]};
        if (debug(1)){console.log(report(pettibone, 'complete [' + eyeD + ']'))};
        if (debug(2)){console.log(report(pettibone, result))};
        return;
    }
// otherwise -
    if (noChart == true) {
        var _array = flagArray(data)    
    } else {
    var entry = game.dndj.chart.find(i => i.id == eyeD);
    var _array = {
        is: true,
        name: entry.name, 
        volume: entry.sliderVol,
        slider: entry.sliderInput,
        itm: entry.inTheMix,
        paused: entry.paused,
        mute: entry.mute,
        elapsed: entry.elapsed,
        duration: entry.duration,
        pinned: entry.pinned,
        playing: entry.playing
        }   
    }        
    await game.user.unsetFlag('DnDj', eyeD);
    await game.user.setFlag('DnDj', eyeD, _array)  
    if (debug(2)){console.log(report(pettibone, 'complete [' + eyeD + ']'))};
}

//--//--//--//--//--//--//--//
// !-- loadin function  --! //
//--//--//--//--//--//--//--//
//
export async function loadIn(whatNigelSays) { 
    var pettibone = 'loadIn';
    var recoveredSetlist = game.user.getFlag('DnDj', 'setlists')
    if (debug(1)){console.log(report(pettibone, whatNigelSays))};
    game.socket.emit("module.DnDj", {type: 'invisibleTouch', who: 'all'});
//
// -- 1) FROM SCRATCH
//
    if (whatNigelSays == 'fromScratch') {
        setTimeout(async function() {
            $('div#loadIn-plate')[0].outerHTML = "";},50);
            game.socket.emit("module.DnDj", {type: 'shutit', who: 'all'});
        for (Playlist of game.playlists.entities){
            Playlist.stopAll();
            for (const sound of Playlist.sounds) {
                if (sound.playing) {
                    await Playlist.updateEmbeddedEntity("PlaylistSound", {_id: sound._id, playing: false})
                }
            }
        }
        await sleep(100);
        $('div#loadIn-screen')[0].outerHTML = "";
    }
//
// -- 2) PLAYING NOW
//
    if (whatNigelSays == 'playingNow') {
        listener.bruteForcePlayingNow();
        for (Playlist of game.playlists.entities){
            for (const sound of Playlist.sounds) {
                if (sound.playing) {
                    if (debug(1)){console.log(report(pettibone, 'chart entry for - ' + sound.name))};
                    if(!(game.dndj.chart.some(e => e.id == sound._id))) {
                        game.dndj.chart.push(addChartEntry(Playlist, sound, false, true, true));
                        // put volume adjust here
                    }
                }   
            }
        }
        //! if (debug(1)){console.log(report(pettibone, game.dndj.chart.filter(es => es.playing)))};
        //console.log(game.dndj.chart)
        var playing = game.dndj.chart.filter(es => es.playing);
        //console.log(game.dndj.chart.filter(es => es.playing))
        for (const chartEntry of playing) {
            chartEntry.wolves.howl.loop(chartEntry.loop);
            mixer.bruteForceVolume(chartEntry, chartEntry.volumeVol);
            listener.signal('volume', chartEntry, null, 'all');
            if (!chartEntry.streaming) {
                chartEntry.duration = chartEntry.wolves.howl._duration;
                chartEntry.ignoreAddPause = false;
            }
        }
        addTrack(playing);
        $('div#loadIn-screen')[0].outerHTML = "";
        listener.heyYou('all');
    }
//
// -- 3) LOAD LAST SESSION
//
    if (whatNigelSays == 'loadLast') {
        if (debug(1)){console.log(report(pettibone, 'recovered setlist - ' +recoveredSetlist.toString()))};
        setTimeout(async function() {
            $('div#loadIn-plate')[0].outerHTML = "";},50);
            game.socket.emit("module.DnDj", {type: 'shutit', who: 'all'});
        for (Playlist of game.playlists.entities){
            for (const sound of Playlist.sounds) {
                Playlist.stopAll();
                if (sound.playing) {
                    await Playlist.updateEmbeddedEntity("PlaylistSound", {_id: sound._id, playing: false})
                }
            }
        }
        game.dndj.status.isLaunch = false;
        for (Playlist of game.playlists.entities){
            for (const sound of Playlist.sounds) {
                if (recoveredSetlist.includes(sound._id)) {
                    if (debug(1)){console.log(report(pettibone, 'loading - ' + sound.name))};
                    await Playlist.updateEmbeddedEntity("PlaylistSound", {_id: sound._id, playing: true})
                } 
            }     
        }
        $('div#loadIn-screen')[0].outerHTML = "";
        await sleep(2000);
    }
    game.dndj.status.isLaunch = false;
    producer.set_isLaunch(false);
    game.settings.set("DnDj", "isLaunch", false);
    if (game.settings.get("DnDj", "gpvHide")) {
        $('input[name="globalPlaylistVolume"]').parent().hide()
    }
    $('input[name="paSlider"]').parent().show();
    game.socket.emit("module.DnDj", {type: 'invisibleTouch', who: 'all', state: false});
    game.dndj.status.addPaused = game.settings.get("DnDj", "pauseAddOpen");
    oneAmAtaWhiteCastle();
    if (debug(1)){console.log(report(pettibone, 'complete'))};
}

//--//--//--//--//--//--//--//--//--//--//--//
// !-- one am at a whitecastle function --! //
//--//--//--//--//--//--//--//--//--//--//--//
//
export function oneAmAtaWhiteCastle(visual) {
    //
    // getting the setlist down three seconds after the last change.
    //
    var intervalLog = game.dndj.intervalLog.setlists;
    if (intervalLog.interval != 'undefined') {
        clearInterval(intervalLog.interval);
    };
    //
    intervalLog.interval = setInterval(
        function () {
            bruteForceFlags(game.user, 'setlists', game.dndj.setlistsII);
            clearInterval(intervalLog.interval);
        }, 3000);
}

//--//--//--//--//--//--//--//--//--//
// !-- add chart entry function --! //
//--//--//--//--//--//--//--//--//--//
//
export function addChartEntry(_playlist, _sound, _push, _ignoreAddPause, _running) {
    //
    var pettibone = 'addChartEntry';
    var eyeD = _sound._id;
    var flag = game.user.data.flags.DnDj[eyeD];
    //
    if (typeof flag != 'undefined') {
        if (debug(2)){console.log(report(pettibone, '(' + eyeD + ') a flag exists (' + decodeURIComponent(_sound.name) + ')'))};
        var flagData = flag;
        var _duration = flagData.duration;
    } else {
        if (debug(2)){console.log(report(pettibone, '(' + eyeD + ') no flag exists (' + decodeURIComponent(_sound.name) + ')'))};
        var flagData = flagArray(_sound);
        if (_running){
            var _duration = _playlist.audio[eyeD].howl._duration;
        } else {
            var _duration = flagData.duration;
        }
    }
    //
    _sound.volume = flagData.volume;
    //
    if (producer._isLaunch) {var _playing = _sound.playing} else {var _playing = flagData.playing};

    if (_ignoreAddPause) {var _paused = false} else {var _paused = flagData.paused};
    //
	if (_sound.flags.bIsStreamed) {
        var streaming = true; var wolves = null;
    } else {
        var streaming = false; var wolves = _playlist.audio[eyeD];
    }
    //
    var chartEntry = {
        id: _sound._id,
        sound: _sound,
        playlist: _playlist,
        volumeVol: flagData.volume,
        volumeInput: flagData.slider,
        sliderVol: flagData.volume,
        sliderInput: flagData.slider,
        fadeBaseInput: parseFloat(flagData.slider),
        meterWidth: flagData.slider*100+'%',
        name: decodeURIComponent(_sound.name),
        playlistName: decodeURIComponent(_playlist.name),
        path: _sound.path,
        inTheMix: false,
        playing: _playing,
        paused: _paused,
        streaming: streaming,
        loop: _sound.repeat,
        live: false,
        cue: false,
        mute: false,
        //playStopButton: false,
        pinned: flagData.pinned,
        wolves: wolves,
        duration: _duration,
        elapsed: flagData.elapsed,
        difference: 0,
        durationDisplay: flagData.duration,
        displaySet: false,
        ignoreAddPause: _ignoreAddPause,
        cssHtml: {
            masterMeterWidth: game.dndj.volumes.masterMeterWidth,
            volMeterWidth: flagData.slider*100+'%',
            inputMeterWidth: flagData.slider*100+'%'},
        masterFader: game.dndj.masterFader,
    };
    //if (debug(1)){console.log(report(pettibone, '(' + eyeD + ') complete'))};
    //
    if (_push) {
        game.dndj.chart.push(chartEntry)
    } else {
        return chartEntry;
    };
}

//--//--//--//--//--//--//--//--//
// !--  add track function  --! //
//--//--//--//--//--//--//--//--//
//
export function addTrack(_array) {
    var pettibone = 'addTrack';
    $.get("modules/DnDj/templates/track.html", async function(data){
        var templateScript = Handlebars.compile(data);
        for (var i = 0; i < _array.length; i++) {
        if (debug(1)){console.log(report(pettibone, _array[i].id + ' (' + _array[i].name + ')'))};
            _array[i].live = false;
            _array[i].inTheMix = true;
            _array[i].masterMeterWidth = game.dndj.volumes.masterMeterWidth
            var html = templateScript(_array[i]);
            $( "#tracks" ).append(html);
            oneAmAtaWhiteCastle();
        }
    });
}

//--//--//--//--//--//--//--//--//--//--//--//
// !--  update playlistSound function   --! //
//--//--//--//--//--//--//--//--//--//--//--//
//
export function uplsFunction(data, _playlist, _sound) {

    if (game.user.isGM && !game.dndj.status.isLaunch) {
        var pettibone = 'uplsF';
        var whatChanged = Object.keys(data)[0];
        var _inTheMix = false;
        if (debug(1)){console.log(report(pettibone, whatChanged.toUpperCase() + '.' + data[whatChanged].toString().toUpperCase() + ' (' + _sound.name + ')'))};
        //if (debug(2)){console.log(report(pettibone, 'isLaunch.' + game.dndj.status.isLaunch + ' | addPaused.' + game.dndj.status.addPaused))};
        //
        var chartEntry = game.dndj.chart.find(ent => ent.id == data._id);
        var _inTheMix = chartEntry.inTheMix;
        var eyeD = data._id;
        ////
        //// -- VOLUME
        ////
        if (whatChanged == 'volume') {
        // - if it's in the mix, update the meter -
            if (_inTheMix) {
                if (game.dndj.rendered){
                    var _volumeToInput = AudioHelper.volumeToInput(data.volume);
                    $('div#track-meter_'+data._id).width((_volumeToInput*100)+'%');
                }
        // - and update theChart either way.
            chartEntry.volume = data.volume;
            }
        }
        ////
        //// -- REPEAT (and pause reset if paused)
        ////
        if (whatChanged == 'repeat') {
            if (chartEntry.playing && !game.dndj.status.isLaunch) {
            }
            chartEntry.loop = data.repeat;
            if (game.dndj.rendered && chartEntry.inTheMix) {
                if (chartEntry.loop) {$('#loop_'+eyeD).addClass('buttonOn')} else {$('#loop_'+eyeD).removeClass('buttonOn')}
            }
        }
        //
        if (whatChanged == 'playing') {
        ////
        //// ! -- PLAYING
        ////
            if (data.playing) {
                game.audio.sounds[chartEntry.path].howl.on('end', function playingEnd() {
                    game.audio.sounds[chartEntry.path].howl.off('end', playingEnd)
                })
                if (_inTheMix) {
                    mixer.bruteForceVolume(chartEntry, chartEntry.volumeVol);
                    listener.signal('volume', chartEntry, null, 'all');
                    $('div#play_'+data._id).removeClass('playStoppedButton');
                    $('div#track-meter_'+data._id).removeClass('track-meter-stopped');
                    $('div#track-meter-live_'+data._id).removeClass('track-meter-stopped');
                    chartEntry.playing = data.playing;
                    bruteForceFlags(_playlist, eyeD, data);
                    oneAmAtaWhiteCastle();
                    return
                };
                //
                if (debug(2)){console.log(report(pettibone, 'paused.' + chartEntry.paused + ' | addPaused.' + game.dndj.status.addPaused + ' (' + chartEntry.name + ')'))};
                //
                if (chartEntry.sound.repeat) {
                    chartEntry.loop = true
                }
                if (chartEntry.streaming) {
                    chartEntry.paused = false;
                    chartEntry.ignoreAddPause = true;
                    chartEntry.playing = true;
                    addTrack(chartEntry);
                    return
                }
                if (game.dndj.status.addPaused) {
                    chartEntry.paused = true;
                    chartEntry.ignoreAddPause = false;	
                    //if (debug(2)){console.log(report(pettibone, 'pausing - ' + chartEntry.name))};
                }
                if (!game.dndj.status.addPaused && !game.dndj.status.isLaunch){
                    chartEntry.paused = false;
                }
                listener.signal('loop', chartEntry, chartEntry.loop, 'all');
                chartEntry.wolves.howl.loop(chartEntry.loop);
                if (!_inTheMix || chartEntry.ignoreAddPause) {
                    //if (debug(2)){console.log(report(pettibone, 'adding - ' + chartEntry.name + ' / ' + chartEntry.playlistName))};
                    chartEntry.inTheMix = true;
                    if (!game.dndj.setlistsII.includes(chartEntry.id)) {
                        game.dndj.setlistsII.push(chartEntry.id)
                    }
                    if (game.dndj.rendered) {
                        $('div#track-play_'+data._id).removeClass('playStoppedButton');
                    }
                    //
                    function onceLoaded(state) {
                        var pettibone = 'onceLoaded';
                        if (debug(2)){console.log(report(pettibone, state + ' (' + chartEntry.name + ')'))};
                        if (chartEntry.paused){
                            mixer.pauseFunction(eyeD, chartEntry, 0, true);
                        } else {
                        mixer.bruteForceVolume(chartEntry, chartEntry.volumeVol);
                        listener.signal('volume', chartEntry, null, 'all');

                        }
                        //
                        chartEntry.duration = chartEntry.wolves.howl._duration;
                        addTrack(game.dndj.chart.filter(ent => ent.id == data._id));
                        if (chartEntry.duration < 3600) {
                            chartEntry.durationDisplay = timeFormat(chartEntry.wolves.howl._duration)['mmss']
                        } else {
                            chartEntry.durationDisplay = timeFormat(chartEntry.wolves.howl._duration)['hhmmss']
                        }
                    }
                    //
                    if (chartEntry.wolves.howl._state == 'loaded') {
                        onceLoaded('*_loaded')
                    };
                    chartEntry.wolves.howl.once('load', function() {
                        onceLoaded('*_onload')
                    });
                }
                chartEntry.playing = data.playing;
                bruteForceFlags(_playlist, eyeD, data);
                oneAmAtaWhiteCastle();
            }
        ///
        //// -- STOPPING
        ////
            if (!data.playing) {
                if (!game.dndj.status.isLaunch) {
                    if (_inTheMix && !chartEntry.pinned) {
                        chartEntry.inTheMix = false;
                    }
                    if (game.dndj.rendered) {
                        if (!chartEntry.inTheMix) {
                            $('div#container_'+data._id)[0].outerHTML = "";
                            mixer.removeDifferent(data._id);
                            game.dndj.setlistsII = game.dndj.setlistsII.filter(e => e !== chartEntry.id);
                        } else {
                            $('div#play_'+data._id).addClass('playStoppedButton');
                            $('div#track-meter_'+data._id).addClass('track-meter-stopped');
                            $('div#track-meter-live_'+data._id).addClass('track-meter-stopped');	
                        }
                    }
                    chartEntry.playing = false;
                    oneAmAtaWhiteCastle();
                } else {
                    chartEntry.playing = false;
                    chartEntry.inTheMix = false;
                }
                bruteForceFlags(_playlist, eyeD, data);
            }
        }
    }
}