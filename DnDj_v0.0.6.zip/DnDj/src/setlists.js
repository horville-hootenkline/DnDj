import * as engineer from './engineer.js';
import {debug, report} from './engineer.js';
import * as mixer from './mixer.js';
import * as listener from './listener.js';


function setlistList() {
    var setlistsArr = [];
    var flagList = Object.values(game.user.data.flags.DnDj).filter(v => v.is == true)
    for (const list of flagList) {
        var lug = {name: list.name};
        console.log(list.name);
        setlistsArr.push(lug);
    }
return setlistsArr;
}

//--//--//--//--//--//--//--//--//--//--//--//--//--//--//
//  * ~ * ~ * ~ *  SETLISTS APPLICATION  * ~ * ~ * ~ *  //
//--//--//--//--//--//--//--//--//--//--//--//--//--//--//


export default class setlists extends Application {

    static get defaultOptions() {
      return mergeObject(super.defaultOptions, {
        id: "setlists",
        classes: ["dndj"],
        template: "modules/DnDj/templates/setlists.html",
        width: 324,
        height: 324,
        left: canvas.app.renderer.width-640,
        minimizable: true,
        resizable: false,
        title: "DnDj - setlists",
      });
    }

    getData(options = {}) {
        return mergeObject(super.getData(), {
            setlists: setlistList()
        });
    }

    activateListeners(html) {
        super.activateListeners(html);

        html.on("click", "#listToggle", event => {
            $('#listToggle').toggleClass('transform-active');
            $('#listHeader').toggleClass('header-closed');
        });

    //
    // -- selecting the selectable
    //
        html.on("change", ".select", event => {
            var pettibone = 'select';
            if (debug(1)){console.log(report(pettibone, $(event.target).attr('id') + ' / ' + $(event.target).find('option:selected').attr('data-attribute')))};
            //
            // -- fade time selection
            //
            if ($(event.target).attr('id') == 'fade') {
                var fade = $(event.target).find('option:selected').attr('data-attribute');
                engineer.bruteForceFlags(game.user, $(event.target).attr('id'), fade);
                game.dndj.mixer.duration = fade;
                game.dndj.mixer.steps = fade*(1000/game.dndj.mixer.delay);
                game.dndj.mixer.display.time = engineer.timeFormat(fade)['fadeTime'];
                $("#control_time").html(game.dndj.mixer.display.time);
                game.dndj.mixer.fraction = 1/(fade*5);

            }
            //
            // -- add paused
            //
            if ($(event.target).attr('id') == 'pauseAddOpen') {
                if ($(event.target).find('option:selected').attr('data-attribute') == 'true') {
                    game.dndj.pauseAdd.open = true;
                    game.settings.set("DnDj", "pauseAddOpen", true)
                } else {
                    game.settings.set("DnDj", "pauseAddOpen", false)
                    game.dndj.pauseAdd.open = false;
                }
            }  
        });
    //
    // -- clicking on the clickable
    //
        html.on("click", ".clickable", event => {
            //
            // CSS reaction (sparkles)
            //
            {$(event.target).removeClass('buttonPressOff').addClass('buttonPress')};
            setTimeout(async function() {
                {$(event.target).removeClass('buttonPress').addClass('buttonPressOff')};
            },100);
            //
            // "what you click thou?"
            //
            var clicked = $(event.target).attr('id').split('_');
            var chartEntry = game.dndj.chart.find(ent => ent.id == clicked[1])
            //
            // "... teach me how to talk to you."
            //
            var pettibone = 'clickable';
            if (typeof chartEntry != 'undefined') {
                if (debug(2)){console.log(report(pettibone, clicked[0] + ' | ' + chartEntry.name))};    
            } else {
                if (debug(2)){console.log(report(pettibone, clicked[0] + ' | ' + clicked[1]))};
            }
            ////
            //// -- LOADIN button
            ////      
            if (clicked[0] == 'loadIn'){
                engineer.loadIn(clicked[1]);
                return;
            }
            ////
            //// -- FADE button
            ////      
            if (clicked[0] == 'fade'){
                if (game.dndj.mixer.different.length > 0) {
                    if (!game.dndj.mixer.fadeButton) {
                        game.dndj.mixer.fadeButton = true;
                        $('#fade_master').addClass('fNsB-stop');
                        $('#fade_master').html('STOP');
                        mixer.fade();
                    } else {
                        game.dndj.mixer.fadeButton = false;
                        $('#fade_master').removeClass('fNsB-stop');
                        $('#fade_master').html('FADE');
                    }
                }
                return
            }
            ////
            //// -- SNAP button
            ////      
            if (clicked[0] == 'snap'){
                if (game.dndj.mixer.different.length > 0) {
                    mixer.snap();
                }
                return
            }
            ////
            //// -- SYNC button
            ////
            if (clicked[0] == 'sync'){
                pettibone = 'sync';
                for (const user of game.users.filter(user => user.active)){
                    if (!user.isGM) {
                        if (debug(2)){console.log(report(pettibone, user.name))};
                        listener.heyYou(user.name)
                    }
                }
                return
            }
            ////
            //// -- RESET (sliders) button
            //// 
            if (clicked[0] == 'reset'){
                mixer.resetSliders();
                return
            }
            ////
            //// -- PLAY/STOP button
            ////      
            if (clicked[0] == 'play'){
                game.dndj.status.human = true;
                chartEntry.playlist.updateEmbeddedEntity("PlaylistSound", {_id: chartEntry.sound._id, playing: !chartEntry.playing});
                return
            }
            ////
            //// -- PAUSE button
            ////      
            if (clicked[0] == 'pause'){
                chartEntry.paused = !chartEntry.paused;
                var gap = game.dndj.chart[0].wolves.howl.seek();
                mixer.pauseFunction(clicked[1], chartEntry, gap, true);
                var state = chartEntry.paused;
                engineer.bruteForceFlags(game.user, chartEntry.id);
                return
            }
            ////
            //// -- REMOVE button
            ////
            if (clicked[0] == 'remove'){
                game.dndj.status.human = true;
                chartEntry.playlist.updateEmbeddedEntity("PlaylistSound", {_id: chartEntry.sound._id, playing: false, volume: chartEntry.volumeVol})
                chartEntry.inTheMix = false;
                return
            }
            ////
            //// -- PIN button
            ////
            if (clicked[0] == 'pin'){
                if (chartEntry.pinned) {
                    chartEntry.pinned = false; $(event.target).removeClass('pinButtonOn');
                    if (!chartEntry.playing) {
                        chartEntry.inTheMix = false;
                        $('div#container_'+chartEntry.id)[0].outerHTML = "";
                    }
                } else {
                    chartEntry.pinned = true; $(event.target).addClass('pinButtonOn');
                }
                engineer.bruteForceFlags(game.user, chartEntry.id);
                return
            }
            ////
            //// -- REW button
            ////
            if (clicked[0] == 'rew'){
                chartEntry.wolves.howl.seek(0);
                listener.signal('elapsed', chartEntry, 0, 'all');
                return
            }
            ////
            //// -- LOOP button
            ////
            if (clicked[0] == 'loop'){
                if (chartEntry.loop) {
                    chartEntry.loop = false; $(event.target).removeClass('buttonOn');
                    chartEntry.wolves.howl.loop(false);
                } else {
                    chartEntry.loop = true; $(event.target).addClass('buttonOn');
                    chartEntry.wolves.howl.loop(true);
                }
                listener.signal('loop', chartEntry, chartEntry.loop, 'all');
                return
            }    
            ////
            //// -- MUTE button
            ////
            if (clicked[0] == 'mute'){
                $('div#track-mute_'+clicked[1]).toggleClass('track-meter-mute');
                if (chartEntry.mute) {
                    chartEntry.mute = false; $(event.target).removeClass('buttonOn');
                    chartEntry.wolves.howl._sounds[0]._node.muted = false;
                    if (chartEntry.live) {
                        $('div#track-meter_'+chartEntry.id).width((((chartEntry.sliderInput*100)/5)*5)+'%');
                    } 
                } else { 
                    chartEntry.mute = true; $(event.target).addClass('buttonOn');
                    chartEntry.wolves.howl._sounds[0]._node.muted = true;
                }
                listener.signal('mute', chartEntry, chartEntry.mute, 'all');
                engineer.bruteForceFlags(game.user, chartEntry.id);
                var state = chartEntry.mute;
                return
            }
            ////
            //// -- LIVE button
            ////
            if (clicked[0] == 'live'){
                if (chartEntry.live) {
                    chartEntry.live = false; $(event.target).removeClass('buttonOn');
                    } else { 
                    chartEntry.live = true; $(event.target).addClass('buttonOn');
                    chartEntry.volumeVol = chartEntry.sliderVol;
                    chartEntry.volumeInput = chartEntry.sliderInput;
                    mixer.removeDifferent(chartEntry.id);
                    chartEntry.difference = 0;
                    mixer.bruteForceVolume(chartEntry, chartEntry.volumeVol)
                    game.socket.emit("module.DnDj", {type: 'volume', who: 'all', id: chartEntry.sound._id, path: chartEntry.path, state: null, volume: chartEntry.volumeVol * game.dndj.volumes.maInput});
                    $('div#track-meter_'+chartEntry.id).width((chartEntry.sliderInput*100)+'%');
                }
                return
            }
            ////
            //// -- CUE button
            ////
            if (clicked[0] == 'cue'){
                if (chartEntry.cue) {
                    chartEntry.cue = false; $(event.target).removeClass('buttonOn');
                    } else { 
                    chartEntry.cue = true; $(event.target).addClass('buttonOn');
                }
                return           
            }
        });
        ////
        //// -- TRACK LISTING scroll
        ////
        html.on("mouseover", ".track-listing-hover", event => {
            var pettibone = 'track-listing-hover';
            var slid = $(event.target).attr('id').split('_');
            var scrollWidth = $('#track-width_'+slid[1]).width();
            if (scrollWidth > 200) {
                var transitionShow = scrollWidth/120;
                var scrollLeft = scrollWidth-200;
                $('#track-listing_'+slid[1]).css({
                    left: -scrollLeft, width: scrollWidth+10, transition: 'left ' + transitionShow + 's, width ' + transitionShow + 's'});
            }
        });

        html.on("mouseout", ".track-listing-hover", event => {
            var slid = $(event.target).attr('id').split('_');
            var scrollWidth = $('#track-width_'+slid[1]).width();
            var transitionHide = scrollWidth/280;
            $('#track-listing_'+slid[1]).css({left: 0, width:220, transition: 'left ' + transitionHide + 's, width ' + transitionHide + 's'});
        });

        ////
        //// -- SLIDERS A (every move you make)
        ////
        html.on("input", ".slider", event => {
            //
            var slid = $(event.target).attr('id').split('_');
            var chartEntry = game.dndj.chart.find(ent => ent.id == slid[1]);
            var _input = parseFloat($(event.target)[0].value);
            if (slid[1] != 'master') {
                chartEntry.sliderInput = _input;
                chartEntry.sliderVol = AudioHelper.inputToVolume(_input);
                chartEntry.cssHtml.inputMeterWidth = chartEntry.sliderInput*100+'%';
                $('div#track-meter-live_'+slid[1]).width(chartEntry.cssHtml.inputMeterWidth);
                if (chartEntry.live && !chartEntry.mute) {
                    chartEntry.volumeVol = chartEntry.sliderVol;
                    chartEntry.fadeBaseInput = chartEntry.sliderInput;
                    chartEntry.volumeInput = chartEntry.sliderInput;
                    mixer.bruteForceVolume(chartEntry, chartEntry.volumeVol)
                    listener.signal('volume', chartEntry, null, 'all');
                    $('div#track-meter_'+chartEntry.id).width(chartEntry.cssHtml.inputMeterWidth);
                    chartEntry.cssHtml.volMeterWidth = chartEntry.cssHtml.inputMeterWidth;
                }
            } else {
                game.dndj.volumes.maInput = _input;
                game.dndj.volumes.masterMeterWidth = parseFloat((1-_input)*100);
                game.dndj.volumes.maVolume = Math.round(AudioHelper.inputToVolume(_input)*100)/100;
                var inTheMix = game.dndj.chart.filter(mf => mf.inTheMix == true);
                $('.track-meter-master').width(game.dndj.volumes.masterMeterWidth+'%');
                for (const chartEntry of inTheMix) {
                    mixer.bruteForceVolume(chartEntry, chartEntry.volumeVol)
                    listener.signal('volume', chartEntry, null, 'all');
                }
            }
        });
        ////
        //// -- SLIDERS B (on release)
        ////
        html.on("change", ".slider", event => {
            //
            var slid = $(event.target).attr('id').split('_');
            if (slid[1] != 'master') {
                var chartEntry = game.dndj.chart.find(ent => ent.id == slid[1]);
                if (chartEntry.volumeInput != chartEntry.sliderInput) {
                    chartEntry.difference = chartEntry.sliderInput - chartEntry.volumeInput;
                    //! console.log(chartEntry.difference)
                    if (!game.dndj.mixer.different.includes(chartEntry.id)) {
                        game.dndj.mixer.different.push(chartEntry.id)   
                    }
                    if (game.dndj.mixer.different.length > 0) {
                        $('#fade_master').addClass('clickable fNsB-go');
                        $('#snap_master').addClass('clickable fNsB-go');
                        $('#reset_master').addClass('clickable rNsB-active');    
                    }
                } else {
                    mixer.removeDifferent(chartEntry.id);
                }  
            } 
            //
            // save 3 seconds after last change (master and volume)
            //
            var intervalLog = game.dndj.intervalLog.masterVol;
            if (intervalLog.interval != 'undefined') {
                clearInterval(intervalLog.interval);
            };
            intervalLog.interval = setInterval(
                function () {
                    if (slid[1] == 'master') {
                        engineer.bruteForceFlags(game.user, 'masterFader', game.dndj.volumes.maInput);
                    } else if (chartEntry.live) {
                        engineer.bruteForceFlags(game.user, chartEntry.id);
                    }
                clearInterval(intervalLog.interval);
            }, 3000);
        });
    }   
}