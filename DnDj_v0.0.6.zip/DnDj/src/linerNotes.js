
export default class ModuleSettings {
     
    static register() {

    game.settings.register("DnDj", "mixerHeight", {
        name: '"Mixer Height"',
        hint: "Set the number of tracks visible at in the mixer",
        scope: "world",
        config: true,
        default: 492,
        type: String,
        choices: {
          340: "2",
          426: "3",
          512: "4",
          598: "5",
          684: "6",
          770: "7",
          856: "8",
          942: "9"
        },

        onChange: (value) => {  console.log(parseInt(value));
                                game.dndj.position.height = parseInt(value);
                                game.dndj.status.trackHeight = (parseInt(value)-168)+'px';
                                game.dndj.render(true);
                            }
      });

      game.settings.register("DnDj", "pauseAddOpen", {
        name: "Load tracks paused when Mixer is OPEN",
        hint: "Add tracks to the open Mixer playing or paused",
        scope: "world",
        config: true,
        default: false,
        type: Boolean,
        onChange: (value)  => { if (game.user.isGM) {
                                    game.dndj.pauseAdd.open = value
                                    if (game.dndj.rendered && game.user.isGM) {
                                        game.dndj.status.addPaused = value;
                                        game.settings.set('DnDj', 'pauseAdd_BOTH', value)
                                    }
                                }
                            }
    });

    game.settings.register("DnDj", "pauseAddClosed", {
        name: "Load tracks paused when Mixer is CLOSED",
        hint: "Adding tracks to the Mixer while it is closed - playing or paused",
        scope: "world",
        config: true,
        default: false,
        type: Boolean,
        onChange: (value)  => { if (game.user.isGM) {
                                    game.dndj.pauseAdd.closed = value;
                                    if (!game.dndj.rendered) {
                                        game.dndj.status.addPaused = value;
                                        game.settings.set('DnDj', 'pauseAdd_BOTH', value)
                                    }
                                }
                            }
    });

    game.settings.register("DnDj", "pauseAdd_BOTH", {
        name: "Load tracks paused [when Mixer is CLOSED]",
        hint: "Adding tracks to the Mixer while it is closed - playing or paused",
        scope: "world",
        config: false,
        default: game.settings.get('DnDj', 'pauseAddClosed'),
        type: Boolean,
        onChange: (value)  => {
        }
    })

    game.settings.register("DnDj", "sequential", {
        name: "Sequential Playlists",
        hint: "Choose whether the next track adds or replaces in the mixer",
        scope: "world",
        config: false,
        default: "replace",
        type: String,
        choices: {
            "add": "add new track - paused",
            "replace": "replace last track with new one - playing",
        },
        onChange: value => {
        }
    });

    game.settings.register("DnDj", "gpvHide", {
        name: "Hide Global Playlist Volume",
        hint: "DnDj has its own playlist volume control. Once DnDj has been launched Foundry's playlist volume control is hidden by default. Uncheck this to unhide.",
        scope: "client",
        config: true,
        default: true,
        type: Boolean,
        onChange: value => { if (value) {
                $('input[name="globalPlaylistVolume"]').parent().hide()
            } else {
                $('input[name="globalPlaylistVolume"]').parent().show()
            } 
        }
    });

    game.settings.register("DnDj", "isLaunch", {
        scope: "world",
        config: false,
        default: false,
        type: Boolean,
        onChange: value => {
        }
    });

      game.settings.register("DnDj", "debug", {
        name: "Talk to Me",
        hint: "Display console debugging info",
        scope: "world",
        config: false,
        default: true,
        type: Boolean,
        onChange: value => {
        }
    });

    game.settings.register("DnDj", "debug_level", {
        name: '"What do you want me to say?"',
        hint: "Set the amount of info the console reports",
        scope: "world",
        config: true,
        default: 1,
        type: String,
        choices: {
          0: "nothing",
          1: "the basics",
          2: "tell me everything"
        },
        onChange: (value) => {  game.dndjRadio.status.debug_level = parseInt(value, 10);
                                if (parseInt(value, 10) > 0) {
                                    game.dndjRadio.status.debug = true;
                                    game.settings.set("DnDj", "debug", true)
                                } else {
                                    game.dndjRadio.status.debug = false;
                                    game.settings.set("DnDj", "debug", false)
                                }
                            }
      });

    game.settings.register("DnDj", "rehaudio", {
        name: "Rebuild the Database on Next Launch",
        hint: "",
        scope: "world",
        config: true,
        default: true,
        type: Boolean,
        onChange: value => {
        }
    });

    }
}