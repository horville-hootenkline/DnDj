import {debug, report} from './engineer.js';
import * as engineer from './engineer.js';
import * as listener from './listener.js';

//--//--//--//--//--//--//--//--//--//--//
// !-- brute force volume function  --! //
//--//--//--//--//--//--//--//--//--//--//
//
function bruteForceVolume(chartEntry, bfVolume) {
    //
    var pettibone = 'bruteForceVolume';
    if (chartEntry.wolves.howl._state == 'loaded') {
        if (debug(2)){console.log(report(pettibone, '*_loaded (' + chartEntry.name +')'))};
        //bfv_cog()
        var vol = bfVolume * game.dndj.volumes.maVolume * game.dndjRadio.volumes.paVolume;
        chartEntry.wolves.howl.volume(vol);
    } else {
    chartEntry.wolves.howl.on('load', function() {
        if (debug(2)){console.log(report(pettibone, '*_onload (' + chartEntry.name +')'))};
        var ping = new Date();
        console.log(ping.getTime());
        //bfv_cog()
        var vol = bfVolume * game.dndj.volumes.maVolume * game.dndjRadio.volumes.paVolume;
        chartEntry.wolves.howl.volume(vol);
        });
    }
    function bfv_cog() {
    var vol = bfVolume * game.dndj.volumes.maVolume * game.dndjRadio.volumes.paVolume;
    chartEntry.wolves.howl.volume(vol);
    }
}

//--//--//--//--//--//--//--//
// !--  pause function  --! //
//--//--//--//--//--//--//--//
//
function pauseFunction(eyeD, chartEntry, _seek, signal) {
    //
    var pettibone = 'pauseFunction';
    //if (debug(2)){console.log(report(pettibone, chartEntry.name + ' - ' + chartEntry.paused))};
    var soundEntry = chartEntry.wolves.howl._sounds.length-1;
    if (!chartEntry.paused) {
        if (!chartEntry.wolves.howl.playing()) {
            chartEntry.wolves.howl.play();
            if (signal) {listener.signal('pause', chartEntry, chartEntry.paused, 'all');}
            bruteForceVolume(chartEntry, chartEntry.volumeVol);
            if (debug(2)){console.log(report(pettibone, ' playing (' + chartEntry.name + ')'))};
            $('div#pause_'+eyeD).removeClass('buttonOn');
            $('div#track-meter_'+eyeD).removeClass('track-meter-paused').addClass('track-meter-playing');
            $('div#track-meter-live_'+eyeD).removeClass('track-meter-paused').addClass('track-meter-playing');
        }
    } 
    if (chartEntry.paused) {
        if (chartEntry.wolves.howl.playing()) {
            chartEntry.wolves.howl.pause();
            //console.log(chartEntry.wolves.howl.pause());
            if (signal) {listener.signal('pause', chartEntry, chartEntry.paused, 'all');}
            bruteForceVolume(chartEntry, 0);
            if (debug(2)){console.log(report(pettibone, ' paused (' + chartEntry.name + ')'))};
            $('div#pause_'+eyeD).addClass('buttonOn');
            $('div#track-meter_'+eyeD).removeClass('track-meter-playing').addClass('track-meter-paused');
            $('div#track-meter-live_'+eyeD).removeClass('track-meter-playing').addClass('track-meter-paused');
            chartEntry.wolves.howl.seek(_seek);
        }
    }
}

//--//--//--//--//--//--//--//--//--//--//
// !-- brute force shh function  --! //
//--//--//--//--//--//--//--//--//--//--//
//
async function bruteForceShhh() {
    for (const entry of game.dndj.chart.filter(as => as.playing)){
                game.dndj.status.human = true;
                await entry.playlist.updateEmbeddedEntity("PlaylistSound", {_id: entry.sound._id, playing: false})
                entry.inTheMix = false;
    }
}

//--//--//--//--//--//--//--//--//--//--//
// !--  counting out time function  --! //
//--//--//--//--//--//--//--//--//--//--//
//
function countingOutTime() {
    //
    // TRACK TIME 
    //
    var tickTock = setInterval(sandsOfTime, 500)    
    function sandsOfTime() {
    //
    // update elapsed time(s)
    //
        var counting = game.dndj.chart.filter(ent => ent.inTheMix && !ent.streaming);
        for (var t=0; t< counting.length; t++) {
            if (counting[t].wolves.howl._duration != 0) {
                if (counting[t].displaySet == false) {
                    if (counting[t].duration < 3600) {
                        counting[t].durationDisplay = engineer.timeFormat(counting[t].wolves.howl._duration)['mmss']
                    } else {
                        counting[t].durationDisplay = engineer.timeFormat(counting[t].wolves.howl._duration)['hhmmss']
                    }
                    counting[t].displaySet = true;
                    $('div#duration_'+counting[t].id).html(counting[t].durationDisplay);
                }
                counting[t].elapsed = counting[t].playlist.audio[counting[t].id].howl._sounds[0]._node.currentTime
                var _elapsed = engineer.timeFormat(counting[t].elapsed);
                
                if (counting[t].duration < 3600) {
                    $('div#timer_'+counting[t].id).html(_elapsed['mmss'])
                } else {
                    $('div#timer_'+counting[t].id).html(_elapsed['hhmmss'])
                }
            }
        }
        // if DnDj is closed, stop counting
        if (!game.dndj.rendered) {
            clearInterval(tickTock);
        }
    }
}

//--//--//--//--//--//--//--//--//--//--//
// !--  remove different function   --! //
//--//--//--//--//--//--//--//--//--//--//
//
function removeDifferent(eyeD) {
    if (eyeD == 'all') {
        game.dndj.mixer.different = [];
    } else if (game.dndj.mixer.different.includes(eyeD)) {
        game.dndj.mixer.different = game.dndj.mixer.different.filter(e => e !== eyeD); 
    }
    if (game.dndj.mixer.different.length == 0) {
        $('#fade_master').html('FADE');
        $('#fade_master').removeClass('clickable fNsB-go fNsB-stop');
        $('#snap_master').removeClass('clickable fNsB-go');
        $('#reset_master').removeClass('clickable rNsB-active'); 
    }
}

//--//--//--//--//--//--//--//
// !--   cue function   --! //
//--//--//--//--//--//--//--//
//
async function cueFunction() {
    var cuedUp = game.dndj.chart.filter(ent => ent.cue && ent.inTheMix);
    for (const chartEntry of cuedUp) {
        if (chartEntry.playing) {
            chartEntry.paused = !chartEntry.paused;
            pauseFunction(chartEntry.id, chartEntry, null, true)
        } else {
            game.dndj.status.human = true;
            chartEntry.playlist.updateEmbeddedEntity("PlaylistSound", {_id: chartEntry.sound._id, playing: !chartEntry.playing});   
        }
        chartEntry.cue = false; $('#cue_'+chartEntry.id).removeClass('buttonOn');
    }
    $('#cueAll_master').removeClass('clickable rNsB-active');
}

//--//--//--//--//--//--//--//--//
// !--  fade stop function  --! //
//--//--//--//--//--//--//--//--//
//
function fadeStop() {
    var pettibone = 'fadeStop';
    if (debug(2)){console.log(report(pettibone, '-'))};
    $("#control_millis").html(game.dndj.mixer.display.millis);
    $("#control_time").html(game.dndj.mixer.display.time);
    $('.track-meter').removeClass('blink-playing blink-paused');
    //
    resetSliders();
}

//--//--//--//--//--//--//--//
// !--  snap function  --!  //
//--//--//--//--//--//--//--//
//
function snap() {
    var pettibone = 'snap';
    if (debug(2)){console.log(report(pettibone, '-'))};
    cueFunction();
    for (const eyeD of game.dndj.mixer.different) {
        var chartEntry = game.dndj.chart.find(ent => ent.id == eyeD);
        chartEntry.volumeVol = chartEntry.sliderVol;
        chartEntry.volumeInput = chartEntry.sliderInput;
        bruteForceVolume(chartEntry, chartEntry.volumeVol);
        chartEntry.cssHtml.volMeterWidth = (chartEntry.sliderInput*100)+'%';
    }
    fadeStop();
}

//--//--//--//--//--//--//--//--//--//
// !--  reset sliders function  --! //
//--//--//--//--//--//--//--//--//--//
//
function resetSliders(){ 
    for (const eyeD of game.dndj.mixer.different){
        var chartEntry = game.dndj.chart.find(ent => ent.id == eyeD);
        // looks
        $('#slider_'+eyeD).prop('value', chartEntry.volumeInput);
        $('div#track-meter-live_'+eyeD).width(chartEntry.cssHtml.volMeterWidth);
        $('div#track-meter_'+eyeD).width(chartEntry.cssHtml.volMeterWidth);
        // brains
        chartEntry.sliderVol = chartEntry.volumeVol;
        chartEntry.fadeBaseInput = chartEntry.volumeInput;
        chartEntry.cssHtml.inputMeterWidth = chartEntry.cssHtml.volMeterWidth;
        // future
        document.getElementById('slider_'+eyeD).disabled = false;
        $('#live_'+chartEntry.id).addClass('clickable');
    }
    removeDifferent('all');
}

//--//--//--//--//--//--//--//
// !--  fade function   --! //
//--//--//--//--//--//--//--//
//
function fade() {
    //
    var pettibone = 'fade';
    var intervalLog = game.dndj.intervalLog.fade;
    if (intervalLog.interval != 'undefined') {
        clearInterval(intervalLog.interval);
    };
    cueFunction();
    //
    var seconds = game.dndj.mixer.duration;
    var step = 1;
    var steps = game.dndj.mixer.steps;
    var fraction = game.dndj.mixer.fraction;
    //
    for (const eyeD of game.dndj.mixer.different) {
        var chartEntry = game.dndj.chart.find(ent => ent.id == eyeD);
        if (!chartEntry.paused) {
            $('#track-meter_'+eyeD).addClass('blink-playing')
        } else {
            $('#track-meter_'+eyeD).addClass('blink-paused')
        }
        document.getElementById('slider_'+eyeD).disabled = true;
        chartEntry.live = false; $(event.target).removeClass('buttonOn');
        if (debug(2)){console.log(report(pettibone, chartEntry.name + ' / ' + chartEntry.volumeVol))}
    }
    $('#snap_master').removeClass('clickable fNsB-go');
    //
    intervalLog.interval= setInterval(function(){
        //
        var progress = step*fraction;
        var liveSeconds = seconds-(progress*seconds)
        //
        // timer
        //
        //console.log(step + ' / ' + liveSeconds + ' / ' + engineer.timeFormat(seconds-(progress*seconds))['mmss']);
        $("#control_millis").html(liveSeconds.toFixed(2).slice(-2));
        $("#control_time").html(engineer.timeFormat(seconds-(progress*seconds))['fadeTime']);
        //
        // volume and track scale
        //
        for (const eyeD of game.dndj.mixer.different) {
            var chartEntry = game.dndj.chart.find(ent => ent.id == eyeD);
            // this is both the value of meter width (*100) and volume output (put through audiohelper)
            var movingVolInput = (chartEntry.fadeBaseInput + (chartEntry.difference * progress))
            chartEntry.volumeVol = AudioHelper.inputToVolume(movingVolInput,2);
            //
            bruteForceVolume(chartEntry, chartEntry.volumeVol);
            listener.signal('volume', chartEntry, null, 'all');
            game.socket.emit("module.DnDj", {type: 'volume', who: 'all', id: chartEntry.sound._id, path: chartEntry.path, state: null, volume: chartEntry.volumeVol * game.dndj.volumes.maInput});
            //
            chartEntry.cssHtml.volMeterWidth = (movingVolInput*100)+'%';
            $('div#track-meter_'+chartEntry.id).width(chartEntry.cssHtml.volMeterWidth);
            chartEntry.volumeInput = movingVolInput;
        }
        if (step == steps || game.dndj.mixer.fadeButton == false) {
            clearInterval(intervalLog.interval);
            fadeStop(); 
            game.dndj.mixer.fadeButton = false;
        }
        step++;
    }, game.dndj.mixer.delay);
}

export {
    countingOutTime,
    pauseFunction,
    bruteForceVolume,
    fade,
    snap,
    removeDifferent,
    resetSliders,
    cueFunction,
    bruteForceShhh
}; 