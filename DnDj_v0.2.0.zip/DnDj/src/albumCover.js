

var button = `
    <button style="min-width: 96%;
                    margin: 1px 2px;
                    height: 30px;
                    border-color: gray;
                    background-size: auto 100%;
                    background-repeat: no-repeat;
                    background-position: center;
                    background-image: url('/modules/DnDj/images/dndj_button.png');">
                    </button>`;

function paSlider(at) {
var slider = `
    <div style="position: relative; min-width: 96%; height: 30px; margin: 2px 2px;">
        <div style="position: absolute; top: -16px; width: 100%; text-align: center">
            <div style="width: 88%; margin: 2px 2px; height: 60px; display: inline-block; background-image: url('/Modules/DnDj/images/personalVolume.svg'); background-repeat: no-repeat; background-size: 100% 100%;"></div>
        </div>
        <div style="position: absolute; top: 5px; width: 100%; text-align: center">
            <div style="height: 20px; width: 88%; display: inline-block;">
                <input id="slider" type="range" class="slider" min="0" max="1" step=".01" value="` + at + `"></input>
            </div>
        </div>
    </div>
`;

var slider2 = `<li class="sound flexrow" id="paSlider-holder">
                    <h4 class="sound-name furnace-qol">Playlists (DnDj)</h4>
                    <input id="paSlider" class="global-volume" name="paSlider" type="range" min="0" max="1" step="0.01" value="` + at + `">
                </li>`

return slider2
}
;

export {button, paSlider};
