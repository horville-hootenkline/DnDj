const CSSstr = `<head>
<style>
.buttonA {position:absolute; width: 36px; padding-top: 0px; height:16px; font-size:11px; border-radius: 4px; text-align: center; border-style: solid; border-width: 1.5px;
}
.buttonMode {position:absolute; width: 42px; padding-top: 0px; height:24px; font-size:11px; border-radius: 4px; text-align: center; line-height: 24px; border-style: solid; border-width: 1px;
}
.playOn {
background-color: rgba(250,100,100);
}
.playOff {
background-color: rgba(190,255,190);
}
</style>
</head>
`
var macroName = "DnDj v.1";
ui.notifications.info('*~* launching ' + macroName + ` *~*`);      

function theMixer(dat) {
console.log('The Mixer');
console.log(dat);
var itmArray = [];
for (let m = 0; m < dat.length; m++) {
    itmArray.push(dat[m].no);
}
        const sleep = (milliseconds) => {
        return new Promise(resolve => setTimeout(resolve, milliseconds))
        }
        var _playlistArray = dat;
        var trackList = [];
        for (var i=0; i < dat.length; i++){
            if (dat[i]._mute == true ) {var muteButton = 'white'; var nameText = 'rgb(130,130,130)';} else {var muteButton = 'rgba(190,190,190)'; var nameText = 'rgb(20,20,20)';};
            if (dat[i]._play == true ) {var playClass = 'playOn'; var playText = 'stop'; var blockBorder = 'rgba(0,0,0,0.9)'; var blockBgd = 'rgba(0,0,0,0.05)';} else {var playClass = 'playOff';  var playText = 'play'; var blockBorder = 'rgba(0,0,0,0.5)'; var blockBgd = 'rgba(0,0,0,0.6)';};
            var volumePercent = dat[i].live;
            trackList = trackList + `
            <div id="top_`+i+`" data-no="`+dat[i].no+`" data-playing="`+ dat[i]._play +`" style="position: relative; padding-left: 0px; left: 0px; font-size:15px; text-align: left; top:-5px; ">
            <div id="block_`+i+`" style="position: absolute; left: -4px; top: -8px; height: 62px; border-style: solid; border-width: 2px; border-color: `+blockBorder+`; width: 370px; background-color: `+blockBgd+`;">
            </div>
            <div id="playlisst_`+i+`" style="position: relative; left: 10px; padding: 3px; top: 30px; text-align: left; font-size: 12px; z-index: 2; visibility: hidden; background-color: rgba(230,230,230,1); display: inline-block;">
            </div>
            <div id="playlist_`+i+`" style="position: absolute; left: -2px; width: 310px; padding: 6px; top: 26px; text-align: left; font-size: 12px; z-index: 2; visibility: hidden; background-color: rgba(230,230,230); display: inline-block;">Playlist: `+ dat[i].playlist+` </br>Track: `+ decodeURIComponent(dat[i].name) +`
            </div>
            <div id="playlistHover_`+i+`" onmouseover="hoverFunction(`+i+`, true)" onmouseout="hoverFunction(`+i+`, false)" style="position: absolute; left: 36px; width: 240px; height:25px; top: 0px; align: right; font-size: 12px; z-index: 2; visibility: visible; background-color: rgba(255,255,255,0); display: inline-block;">
            </div>
            <div style="position: absolute; top: 0px; width: 70%;">
            <div style="position: absolute; z-index: 0; padding-left: 0px; left: -2px; padding-top: 0px; margin-bottom: 25px; top: -6px; height: 35px; width: 366px; background-color: rgba(255,253,250,.5); font-size: 14px; overflow: no wrap; text-overflow: ellipsis; white-space: nowrap; display: inline-block;">
            <div id="name_`+i+`" style="position: relative; z-index: 1; padding-left: 8px; left: 28px; padding-top: 0px; margin-bottom: 25px; top: 5px; height: 24px; width: 260px; font-size: 17px; color: `+nameText+`; white-space: nowrap; text-overflow: ellipsis; display: block; overflow: hidden">` + decodeURIComponent(dat[i].name) + `
            </div>
            </div>
            </div>
            <div style="position: relative; top: -10px; left:-4px;">
            <div style="position: absolute; top: 17px; left: 2px; height: 26px; width: 99%; background-color: rgba(200,200,200,1);"></div>
            <div style="position: relative; padding-left: 10px; margin-bottom: 12px; height: 48px;">
            <div id="bigDial_`+i+`" style="position:absolute; width: 54px; right: -12px; top: 10px; padding-top: 2px; height:40px; font-size:20px; background-color: `+blockBorder+`; text-align: center; color: rgba(255,255,255,.9);"></div>
            <div id="dial_`+i+`" style="position:absolute; width: 50px; right: -10px; top: 12px; padding-top: 2px; height:36px; font-size:20px; background-color: rgba(40,40,40); text-align: center; color: rgba(255,255,255,.9); border-style: solid; border-width: 2px; border-color; white;"></div>
            <div id="dialSlider_`+i+`" style="position:absolute; top: 16px; right: -6px; height:28px; line-height:28px; font-size: 24px; color: rgb(255,255,255,.9);">` + volumePercent + `</span></div>
<div id="dialVolBack" style="position:absolute; width: 26px; right: 23px; top: 20px; height: 20px; font-size:14px; line-height:16px; text-align: center; color: rgb(255,255,255,.9); background-color: rgba(40,40,40);"></div>
            <div id="dialVol_`+i+`" style="position:absolute; width: 24px; right: 24px; top: 21px; height: 18px; font-size:14px; line-height:16px; text-align: center; color: rgb(255,255,255,.9); background-color: rgba(40,40,40); border-style: solid; border-width: 1.5px; border-color; white;">` + volumePercent + `</div>
            <div style="position: absolute; top: 30px; left: 10px;">
            <div id="bar1_overflow_` + i + `" style="position: relative; top: -6px; top-padding: 4px; left: ` + ((volumePercent*2.86)+6) + `px; width: 300px; height: 14px; overflow: hidden; background-color: rgba(0,0,255,0)">
                <div id="bar1_` + i + `" style="position: absolute; left: -400px; width: 400px; top: 0px; height: 13px; border: 1px; background-color: rgba(0,255,0,.5);" value="` + volumePercent + `">
                </div>
            </div>
            <div style="position: absolute; left: 0px;">
            <div id="bar2_overflow_` + i + `" style="position: relative; z-index: 0; top: -20px; top-padding: 0px; width: ` + ((volumePercent*2.86)-2) + `px; height: 13px; overflow: hidden; background-color: rgba(0,0,255,0)">
                <div id="bar2_` + i + `" style="position: absolute; z-index: 0; left: `+ ((volumePercent*2.86)+6) + `px; width: 400px; top: 0px; height: 13px; border: 1px; background-color: rgba(255,0,0,.5);">
                </div></div></div>
            <div id="current_` + i + `" style="position: absolute; z-index: 0; left: ` + ((volumePercent*2.86)-2) + `px; width: 19px; top: -9px; height: 19px; background-color: rgba(180,180,180,1); align: center; border-style: solid; border-width: 2px; border-color: black;" value="` + volumePercent + `">
            <div id="currentNum_` + i + `" style="position: relative; z-index: 1; padding: 0px; left: -11px; width: 30px; top: 10px; font-size: 0px; text-align: center; background-color: rgba(255,0,255,0)">` + volumePercent/100 + `
            </div></div></div>
            <div style="position: absolute; top:19px; width: 300px; margin-bottom: 15px;"><input type="range" class="slider" id="sliderRange_`+ i +`" oninput="sliderFunction(`+i+`)" value="` + volumePercent + `">
            </div>
             <div style="position: absolute; width: 78px; height: 20px; right: -3.5px; top: -12.5px; border-radius: 4px; border-style: solid; border-width: 1px;"></div>
            <div id="roc_`+i+`" class="buttonA" onclick="rocFunction(`+i+`)" data-value="false" style="left: 328px; top: -10px; line-height: 12px; font-size:10px; background-color: rgb(190,190,190);">on cue</div>
            <div id="play_`+i+`" class="`+ playClass + ` buttonA" onclick="playFunction(`+i+`)" data-value="false" style="left: 290px; top: -10px; line-height: 12px;">` + playText + `</div>
            <div id="mute`+i+`" class="buttonA" data-mute`+i+`="`+ dat[i]._mute +`" onclick="muteFunction(`+i+`)" data-value="false" style="width: 28px; left: 4px; top: -11px; padding-top: 1px; height:18px; font-size:10px;  background-color: `+muteButton+`; border-color: rgba(56,56,56);">mute</div>
            </div>
            </div>`
        }
        const we = 12;
var options = "";
var optionsArray = [3,4,6,8,12,16,20,24,30,45,60,90,120,240,300];
for (var n = 0; n < optionsArray.length; n++) {options = options + '<option value="'+optionsArray[n]+'">'+optionsArray[n]+' secs</option>'}
        var controls = `
            <div id="master" data-length="`+dat.length+`" style = "position: relative; top: -10px; height 30px; width:380px; left: -8px; padding: 5px; border-style: solid; border-width: 1px; border-color: rgba(56,56,56,.5);">
            <button type="button" id="snapButton" style="width: 120px; font-size: 18px; background-color: rgba(144,144,255,0.4)" onclick="snapFunction()">SNAP</button><button type="button" id="goButton" style="width: 120px; font-size: 18px; background-color: rgba(0,220,0,0.4)" onclick="buttonFunction()">FADE</button>
            <div style="position: absolute; align: left; top: 11px; right: 100px; height: 10px; font-size: 16px">----</div>
            <div style="position: absolute; text-align: right; top: 9px; right: 5px; height: 10px; font-size: 16px">
            <select name="fade" id="fade" style="font-size: 16px;">` + options + `</select></div></div></div>
            `;
        //
        let dndjDialog = new Dialog({
        title: `DnDj v.1 - MIXER`,
        content: `${CSSstr}<body><div style="width:100%; height:100%;"><div style="padding: 16px 12px 10px 10px;">
            ${trackList}${controls}
            <script>
            //
            // 'soundDeck' - create master array of all tracks in mixer with their associated data.
            //
            var _tracksArray = [];
            var _muteArray = [];
            var _playingArray = [];
            noTracks = parseInt($('#master').data('length'),10);
            for (var m = 0; m < noTracks; m++) {
                _tracksArray.push(parseInt($('#top_'+m).data('no'),10));
                _muteArray.push($('#mute'+m).data('mute'+m));
                _playingArray.push($('#top_'+m).data('playing'));
            }
//console.log(_playingArray);
            var soundDeck = [];
            var all = game.playlists.directory.entities;
            var track = 0; var inn = 0;
            for (var i = 0; i < all.length; i++){
                  var tracksArray = all[i].sounds;
                  for (var e = 0; e < tracksArray.length; e++){
                  if (_tracksArray.includes(track) == true) {
                            soundDeck.push({
                            no: track,
                            name: tracksArray[e].name,
                            id: tracksArray[e]._id,
                            sound: tracksArray[e],
                            newVol: Math.round(tracksArray[e].volume*100),
                            live: Math.round(tracksArray[e].volume*100),
                            playlist: all[i].name,
                            roc: false,
                            _play: _playingArray[inn],
                            _mute: _muteArray[inn]
                        });
                        inn++;
                        }
                  track++;
                  }
            }
            // console.log(soundDeck);
            // 'harry' - our style array
            //
            var harry = [{ text: 'rgba(20,20,20)', halt: 'rgba(150,150,220,0.9)', bar1: 'rgba(0,255,0,.5)', bar2: 'rgba(255,0,0,.5)', dialWhite: 'white', dialGray: 'rgba(255,255,255,.8)', muteOn: 'white', muteOff: 'rgba(190,190,190)', muteText: 'rgba(130,130,130)', rocOn: 'rgba(225,100,100,.5)', rocOnPlay: 'rgba(100,255,100,.5)', rocOnStop: 'rgba(225,100,100,.6)', rocOff: 'rgba(190,190,190)', playOn: 'rgba(250,100,100,.6)', playOff: 'rgba(100,250,100,.6)',
            }];
            //'100% FUNCTION - formats text for the extra 0
            //
            async function hundredPercent(w) {
                if (soundDeck[w].live == 100) {
                        document.getElementById('dialSlider_'+w).style.fontSize = '18px';
                        document.getElementById('dialSlider_'+w).style.right = '-6px';
                        document.getElementById('dialVol_'+w).style.fontSize = '12px';
                        } else {
                        document.getElementById('dialSlider_'+w).style.fontSize = '24px';
                        document.getElementById('dialSlider_'+w).style.right = '-4px';
                        document.getElementById('dialVol_'+w).style.fontSize = '14px';
                }
            }
            // MUTE FUNCTION - mutes track without altering volume slider etc
            //
            async function muteFunction(shh) {
                let playlist = game.playlists.find(p => p.name === soundDeck[shh].playlist);
                let sound = playlist.sounds.find(s => s.name === soundDeck[shh].name);
                if (soundDeck[shh]._mute) {
                        soundDeck[shh]._mute = false;
                        document.getElementById('mute'+shh).setAttribute('data-value', 'false');
                        playlist.updateEmbeddedEntity("PlaylistSound", {_id: sound._id, volume: soundDeck[shh].live/100, playing: true});
                        document.getElementById('mute'+shh).style.backgroundColor = harry[0].muteOff;
                        console.log(soundDeck[shh].name + ' is unmuted');
                        document.getElementById('name_'+shh).style.color = harry[0].text;
                } else {
                        soundDeck[shh]._mute = true;
                        document.getElementById('mute'+shh).setAttribute('data-value', 'true');
                        playlist.updateEmbeddedEntity("PlaylistSound", {_id: sound._id, volume: 0, playing: true});
                        document.getElementById('mute'+shh).style.backgroundColor = harry[0].muteOn;
                        console.log(soundDeck[shh].name + ' is muted');
                        document.getElementById('name_'+shh).style.color = harry[0].muteText;
                }     
            }
            // PLAY FUNCTION - button/macro function for 'roc' which restarts track on next SNAP or FADE
            //
            async function playFunction(spin) {
                let playlist = game.playlists.find(p => p.name === soundDeck[spin].playlist);
                let sound = playlist.sounds.find(s => s.name === soundDeck[spin].name);
                if (soundDeck[spin]._play) {
                        soundDeck[spin]._play = false;
                        playlist.updateEmbeddedEntity("PlaylistSound", {_id: sound._id, playing: false});
                        document.getElementById('play_'+spin).setAttribute('data-value', 'false');
                        document.getElementById('play_'+spin).innerHTML = 'play';
                        document.getElementById('play_'+spin).className = 'buttonA playOff';
                        document.getElementById('block_'+spin).style.backgroundColor = 'rgba(0,0,0,0.6)';
                        console.log(soundDeck[spin].name + ' stopped');
                } else {
                        soundDeck[spin]._play = true;
                        playlist.updateEmbeddedEntity("PlaylistSound", {_id: sound._id, playing: true});
                        document.getElementById('play_'+spin).setAttribute('data-value', 'true');
                        document.getElementById('play_'+spin).innerHTML = 'stop';
                        document.getElementById('play_'+spin).className = 'buttonA playOn';
                        document.getElementById('block_'+spin).style.backgroundColor = 'rgba(0,0,0,0.05)';
                        console.log(soundDeck[spin].name + ' started');
                }     
            }
            // ROC FUNCTION - button/macro function for 'roc' which restarts track on next SNAP or FADE
            //
            async function rocFunction(spin) {
                let playlist = game.playlists.find(p => p.name === soundDeck[spin].playlist);
                let sound = playlist.sounds.find(s => s.name === soundDeck[spin].name);
                if (soundDeck[spin].roc) {
                        soundDeck[spin].roc = false;
                        document.getElementById('roc_'+spin).setAttribute('data-value', 'false');
                        document.getElementById('roc_'+spin).style.backgroundColor = harry[0].rocOff;
                        document.getElementById('roc_'+spin).innerHTML = 'on cue';
                        console.log(soundDeck[spin].name + ' will not ROC');
                } else {
                        soundDeck[spin].roc = true;
                        
                        document.getElementById('roc_'+spin).setAttribute('data-value', 'true');
                       // document.getElementById('roc_'+spin).style.backgroundColor = harry[0].rocOn;
                        if (soundDeck[spin]._play == true) {document.getElementById('roc_'+spin).style.backgroundColor = harry[0].rocOnStop} else {document.getElementById('roc_'+spin).style.backgroundColor = harry[0].rocOnPlay};
                        document.getElementById('roc_'+spin).innerHTML = 'on cue';
                        console.log(soundDeck[spin].name + ' will ROC');
                }     
            }
            // ROC ON FUNCTION - performs the system actions for roc
            //
            async function rocOn(playlist, sound) {
if (sound.playing == true) {console.log('stopping '+ sound.name+ ' on cue')};
                await playlist.updateEmbeddedEntity("PlaylistSound", {_id: sound._id, playing: false}).then(() => {
                playlist.updateEmbeddedEntity("PlaylistSound", {_id: sound._id, playing: true})
                });
            }
            // HOVER FUNCTION - shows playlist on hover - very rough atm
            //
            function hoverFunction(p, q) {
                if (q == true) {
                        document.getElementById('playlist_'+p).style.visibility = 'visible';
                }
                if (q == false) {
                        document.getElementById('playlist_'+p).style.visibility = 'hidden';
                }
            }
            // somehousekeeping - go-button declared false and checking for 100%
            //
            var buttonState = false;
            for (var e = 0; e < soundDeck.length; e++){
                hundredPercent(e);
            }
            // SLIDER FUNCTION - update and display
            //
            function sliderFunction(number) {
                var origin = soundDeck[number].live;
                var input = document.getElementById('sliderRange_'+number).value;
                var live_ = (soundDeck[number].live);
                document.getElementById('dialSlider_'+number).innerHTML = live_;
                document.getElementById('dialVol_'+number).innerHTML = input.padStart(2, '0');
                document.getElementById('bar1_overflow_'+number).style.left = ((soundDeck[number].live*2.86)-2) +'px';
                document.getElementById('bar2_overflow_'+number).style.width = ((soundDeck[number].live*2.86)-2) +'px';
                document.getElementById('bar2_'+number).style.left = ((input*2.86)+6) + 'px';
                document.getElementById('bar1_'+number).style.left = ((input*2.86)+6)-(soundDeck[number].live*2.86)-400 + 'px';
                var diff = input-origin;
                if (input == 100 || input == 0) {
                        document.getElementById('dialVol_'+number).style.fontSize = '12px';      
                        } else {
                        document.getElementById('dialVol_'+number).style.fontSize = '14px';
                }
                if (input == 0) {
                        document.getElementById('dialVol_'+number).innerHTML = '--';      
                }       
                if (diff > 0) {
                document.getElementById('dialVol_'+number).style.color = 'rgba(0,255,0,0.9)';
                document.getElementById('dialSlider_'+number).style.color = 'rgba(255,255,255,.8)';
                } else if (diff == 0) {
                        document.getElementById('dialVol_'+number).style.color = 'white';
                        document.getElementById('dialSlider_'+number).style.color = 'white';
                        } else {
                        document.getElementById('dialVol_'+number).style.color = 'rgba(255,90,90)';
                    document.getElementById('dialSlider_'+number).style.color = 'rgba(255,255,255,.8)';
                }
                soundDeck[number].newVol = input;
            }
            // STOP FUNCTION - for fade abort/halt and resetting at the end of a fade
            //
            async function stopFunction(thisU, newVol, sound, halt, playlist) {
                console.log('stopFunction');
                if (soundDeck[thisU]._mute == false) {playlist.updateEmbeddedEntity("PlaylistSound", {_id: sound._id, volume: newVol/100})};
                const sleep = (milliseconds) => {
                        return new Promise(resolve => setTimeout(resolve, milliseconds))
                }
                soundDeck[thisU].live = newVol;
                // **** ROC ****
                document.getElementById('roc_'+thisU).style.backgroundColor = harry[0].rocOff;
                soundDeck[thisU].roc = false;
                if (halt == true) {
                        console.log('halted');
                        var haltColor = 'rgba(90,90,190,0.9)';
                        document.getElementById('goButton').style.backgroundColor = harry[0].halt;
                        document.getElementById('goButton').innerHTML = 'HALTED'; 
                        document.getElementById('bar1_'+thisU).style.backgroundColor = harry[0].halt;
                        document.getElementById('bar2_'+thisU).style.backgroundColor = harry[0].halt;
                        await sleep(1800);
                        document.getElementById('bar1_'+thisU).style.backgroundColor = harry[0].bar1;
                        document.getElementById('bar2_'+thisU).style.backgroundColor = harry[0].bar2;
                }
                if (halt == true) {await sleep(300);}
                buttonState = false;
                document.getElementById('goButton').style.backgroundColor = 'rgba(0,220,0,0.4)';
                document.getElementById('goButton').innerHTML = 'GO'; 
                console.log('buttonState = ' + buttonState);
                hundredPercent(thisU);
                document.getElementById('sliderRange_'+thisU).value = newVol;
                sliderFunction(thisU);
            }
            // SNAP FUNCTION - snaps to desired position, and delays visual update in order to be less confusing
            //
            function snapFunction() {
                console.log('SNAP');     
                for (let u = 0; u < soundDeck.length; u++){
                        if (soundDeck[u].roc == true) {
                            //let playlist = game.playlists.find(p => p.name === soundDeck[u].playlist);
                            //let sound = playlist.sounds.find(s => s.name === soundDeck[u].name);
                            playFunction(u);
                            document.getElementById('roc_'+u).style.backgroundColor = harry[0].rocOff;
                            soundDeck[u].roc = false;
                        }   
                        if (soundDeck[u].live != soundDeck[u].newVol) {
                            soundDeck[u].live = soundDeck[u].newVol;
                            hundredPercent(u);
                            let playlist = game.playlists.find(p => p.name === soundDeck[u].playlist);
                            let sound = playlist.sounds.find(s => s.name === soundDeck[u].name);
                            if (soundDeck[u]._mute == false) {
                                    playlist.updateEmbeddedEntity("PlaylistSound", {_id: sound._id, volume: soundDeck[u].newVol/100, playing: true});
                            }
                           sliderFunction(u)
                           document.getElementById('current_'+u).style.left = ((soundDeck[u].newVol*2.862)-2) +'px';
    
                           // document.getElementById('bar1_'+u).style.left = ((soundDeck[u].newVol*2.86)+6)-(soundDeck[u].newVol*2.86)-400 +'px';
                           // document.getElementById('bar2_'+u).style.left = ((soundDeck[u].live*2.86)+6) + 'px';
                           // document.getElementById('bar1_overflow_'+u).style.left = ((soundDeck[u].newVol*2.86)-2) +'px';
                          //  document.getElementById('bar2_overflow_'+u).style.width = '0px';
                            
                          //  document.getElementById('dialSlider_'+u).style.color = 'rgba(255,255,255,1)';
                          //  document.getElementById('dialSlider_'+u).innerHTML = Math.round(soundDeck[u].newVol);
                          //  document.getElementById('dialVol_'+u).style.color = 'rgba(255,255,255,.9)';
                            console.log('snap complete : ' + soundDeck[u].name);
                        }
                }
            }
            // 'GO' function
            //
            function buttonFunction() {
                var totalDiff = 0;
for (let b = 0; b < soundDeck.length; b++) {
                totalDiff = totalDiff + (document.getElementById('sliderRange_'+b).value - soundDeck[b].live);
}         
                console.log('totalDiff = ' +totalDiff);
console.log('bottonState = ' +buttonState);
                if (buttonState == false && totalDiff != 0) {
                        buttonState = true;
                       //document.getElementById('goButton').style.backgroundColor = 'rgba(255,0,0,0.9)';
                        } else {
                        buttonState = false;
                } 
                if (buttonState == false && totalDiff == 0) {
                    console.log('rocking');
                    for (let u = 0; u < soundDeck.length; u++){
                            if (soundDeck[u].roc == true) {
                            playFunction(u);
                            document.getElementById('roc_'+u).style.backgroundColor = harry[0].rocOff;
                           soundDeck[u].roc = false;
                           } 
                      }
return;
                }
                const sleep = (milliseconds) => {
                return new Promise(resolve => setTimeout(resolve, milliseconds))
                }
                const time = document.getElementById("fade").value;
                //document.getElementById('goButton').style.backgroundColor = 'rgba(255,0,0,0.9)';
                var steps = (time*5);
                var steps2 = (time*4);
                // counter for the GO button
                //
                async function fadeCount(steps, time) {
                        for (let a = 0; a <= steps; a++) {
                        document.getElementById('goButton').style.backgroundColor = 'rgba(255,0,0,0.9)';
                            await sleep(200)
                            if (buttonState == false) {
                                    document.getElementById('goButton').innerHTML = 'GO'; return;
                            }
                            document.getElementById('goButton').innerHTML = (time*((steps-a)/steps)).toFixed(1);
                        }
                }
               if (totalDiff != 0) {fadeCount(steps, time)};
                for (let u = 0; u < soundDeck.length; u++){
                        let newVol = document.getElementById('sliderRange_'+u).value;
                        soundDeck[u].newVol = newVol;
                        if (soundDeck[u].live != newVol) {
                            if (soundDeck[u].roc == true) {
                              playFunction(u);
                               document.getElementById('roc_'+u).style.backgroundColor = harry[0].rocOff;
                             soundDeck[u].roc = false;
                           } 
                            let y = u;
                            let playlist = game.playlists.find(p => p.name === soundDeck[u].playlist);
                            let sound = playlist.sounds.find(s => s.name === soundDeck[u].name);
                            var oldVol = (soundDeck[u].live*100)/100;
                            var gap = (newVol-oldVol)/100;
                            var increment = gap/steps;
                            var workingVol = oldVol/100;
                            let thisU = u;
                            console.log('newVol = ' + soundDeck[thisU].newVol/100);
                            console.log('vol = ' + soundDeck[thisU].sound.volume);
                        //
                        //
                        async function volumeAdjuster(playlist, sound, toot) {
                            if (toot < 0 || toot > 1) {
                                    return;
                            } else {
                            playlist.updateEmbeddedEntity("PlaylistSound", {_id: sound._id, volume: toot})
                            }
                        }
                        // act - putting it all together
                        //
                        async function act(playlist, sound, workingVol, increment, steps, newVol) {
                            console.log('act running');
                            document.getElementById('dialVol_'+thisU).innerHTML = newVol;
                            for (let a = 0; a < steps; a++) {
                                if (buttonState == false) {stopFunction(thisU, Math.round(workingVol*100, sound, true, playlist, sleep), sound); break;}
                                    await sleep(200)
                                    workingVol = workingVol + increment;
                                    if (soundDeck[thisU]._mute == false) {
                                        volumeAdjuster(playlist, sound, workingVol.toFixed(3))
                                    }
                                    var liveVol = Math.round(workingVol*100);
                                    soundDeck[thisU].live = liveVol;
                                    document.getElementById('dialSlider_'+thisU).innerHTML = Math.round(liveVol); 
                                    document.getElementById('current_'+u).style.left = ((workingVol*286)-2) +'px';
                                    document.getElementById('bar2_overflow_'+thisU).style.width = ((liveVol*2.86)-2) +'px';
                                    document.getElementById('bar1_overflow_'+thisU).style.left = ((liveVol*2.86)-2) +'px';
                                    document.getElementById('bar1_'+thisU).style.left = (soundDeck[thisU].newVol*2.86)-((liveVol*2.86)-6)-400 + 'px';
                                    if (buttonState == false) {
                                        stopFunction(thisU, liveVol, sound, true, playlist); 
                                            console.log('stopped');
                                            break;
                                        }
                                        //console.log('liveVol = '+(Math.round(workingVol*100))+' | newVol = '+newVol)
                                    }
                                if (Math.round(workingVol*100) == newVol) {
                                    soundDeck[thisU].live = newVol;
                                    stopFunction(thisU, newVol, sound, false, playlist, sleep);
                                }                                                       
                            }
                            act(playlist, sound, workingVol, increment, steps, newVol);
                        }
                    }
                }
            </script>
                
        `,
        buttons: { 
            one: {
            icon: "",
            label: `cancel`,
            callback: html => {return;
        }
        },
            two: {
            icon: "",
            label: `EDIT LIST`,
        callback: html => {theList(false, soundDeck);
    
            
        }
        },
        }
        });
    
        dndjDialog.render(true)
    }
//////////////////////////////////////////////
////          ---  THE LIST ---          ////
/////////////////////////////////////////////    

   async function theList(isLaunch, soundDeck) {
console.log('**** soundDeck ****');
console.log(soundDeck);
var alreadyIn = [];
if (isLaunch == false) {
for (let m = 0; m < soundDeck.length; m++) {
    alreadyIn.push(soundDeck[m].id);
}
var theSilentArr = [];
var theSilent = soundDeck.filter(pl => pl._mute == true);
for (let m = 0; m < theSilent.length; m++) {
    theSilentArr.push(theSilent[m].id);
}
console.log(`Launching list - tracks already in: `);
console.log(alreadyIn);
console.log(`Mantaining MUTE on these: `);
var theSilentStr = theSilentArr.toString();
console.log(theSilentStr);
} else {
var theSilentStr = "nope";
var playStr = "nope";
var all = game.playlists.directory.entities;
console.log(`Launch List for 1st time - tracks playing:`);
    for (var i = 0; i < all.length; i++){
          var tracksArray = all[i].sounds;
          for (var e = 0; e < tracksArray.length; e++){
              if (tracksArray[e].playing == true) {
          console.log(tracksArray[e].name);
       alreadyIn.push(tracksArray[e]._id);
              }
              }}
}
var itmStr = alreadyIn.toString();

    var pool = ui.playlists.entities;
    
    var plOptions = `<option value="start">- - - add from playlists - - -</option>`;
    
    for (var i=0; i < pool.length; i++){
    var option = `<option value="`+ i +`">`+ pool[i].name + `</option>`;
    plOptions = plOptions + option;
    }
    var trOptions = "";
    const jup = pool.length;
    var html =`
    <div id="all" data-itm="`+ itmStr +`" data-ts="`+ theSilentStr +`"><div style="position: relative; width: 100%; height: 420px; padding: 5px; padding bottom: 10; overflow-x: hidden; visibility: visible; overflow-y: visible; text-overflow: ellipsis; text-align: left; font-size: 16px">
    <div id="billboard" style="height: 260px; width: 100%; overflow: auto; position; relative; white-space: nowrap; display: inline-block;"></div>
    <div style="position:absolute; bottom: 10px; left:63px; align-vertical: bottom; width: 100%;"><div id="mode" data-mode="" class="buttonMode" onclick="modeButton()" style="left: -60px; width: 60px; top: .5px"></div>
    <select id="plSelect" style="width: 318px; font-size: 15px; background-color: rgb(255,255,255,.2); align: left; text-align-last: center;" onchange="plChange()">` + plOptions + `</select></br>
    <div id="trDiv" style="visibility: hidden; position: relative; top: 0px; left: -61px; height: 0px; overflow: hidden; align-vertical: bottom;"><select id="trSelect" size="6" style="width: 99%; height: 100%; background-color: rgb(255,255,255,.4); font-size: 15px; overflow-y: scroll; text-align-last: left;" onchange="trChange('selected')">` + trOptions + `</select></div><div style="position: absolute; top: -40px; right: 0;"></div>
    </div>
    <div></div></div>
    <script>
    var ids_itm = $('#all').data('itm').split(",");
    var ids_ts = $('#all').data('ts').split(",");
    var modes = ["board","sequence","shuffle","simult"];
    var all = game.playlists.directory.entities;
    var chart = [];
    var _no = 0;
    for (var i = 0; i < all.length; i++){
          var tracksArray = all[i].sounds;
          for (var e = 0; e < tracksArray.length; e++){
                chart.push({no: _no, name: decodeURIComponent(tracksArray[e].name), playlist: all[i].name, plNo: i, plMode: all[i].mode, plArr: all[i], sound: tracksArray[e], playing: tracksArray[e].playing, newVol: Math.round(tracksArray[e].volume*100), live: Math.round(tracksArray[e].volume*100), roc: false, _mute: ids_ts.includes(tracksArray[e]._id), _loop: tracksArray[e].repeat, _play: tracksArray[e].playing, inTheMix: ids_itm.includes(tracksArray[e]._id)});
                _no++; 
    }}
    // playlist and track selection display //
    //
    function plChange() {
    var x = document.getElementById('plSelect').value;
    if (x != 'start') {console.log('Selection Box Visible'); document.getElementById("trDiv").style.visibility = "visible"; document.getElementById("trDiv").style.height = "100%";};
    var album = chart.filter(pl => pl.plNo == x);
    $('#all').data('mode', album[0].plArr._id);
    var trOptions = "";
    document.getElementById("mode").innerHTML = modes[album[0].plMode+1];
    for (var j=0; j < album.length; j++){
    if (album[j].inTheMix == true) {
    var option2 = '<option value="null" style="text-decoration: line-through; color: rgb(0,0,0,.5);">'+ decodeURIComponent(album[j].name) + '</option>';
    console.log(album[j].no + ': ' + album[j].name + ' = struck');
    } else {
    var option2 = '<option value="'+ album[j].no +'" >'+ decodeURIComponent(album[j].name) + '</option>';
    }
    trOptions = trOptions + option2;
    }
    document.getElementById("trSelect").innerHTML = trOptions;
    }
    // remove entry function
    //
    function removeFunction(entry) {
    var myobj = document.getElementById(entry);
    chart[entry].inTheMix = false;
    myobj.remove();
    console.log(entry+': removed');
    plChange();
    }
    //
    //
    async function modeButton() {
        let playlist = game.playlists.find(p => p._id ===  $('#all').data('mode'));
        await playlist.cycleMode().then(() => { document.getElementById("mode").innerHTML = modes[playlist.mode+1];});
    }

    var toggleOn = 'rgba(249,249,249,1)';
    var toggleOff = 'rgba(200,200,200,1)';
    
    function muteFunction(mute) {
          if (chart[mute]._mute == false) {
                chart[mute]._mute = true;
                document.getElementById('mute_'+mute).style.backgroundColor = toggleOn;
          } else 
          if (chart[mute]._mute == true) {
                chart[mute]._mute = false;
                document.getElementById('mute_'+mute).style.backgroundColor = toggleOff;
          }
    console.log(mute + ' : mute = ' + chart[mute]._mute)
    }
    
    function loopFunction(loop) {
          if (chart[loop]._loop == false) {
                chart[loop]._loop = true;
                document.getElementById('loop_'+loop).style.backgroundColor = toggleOn;
                chart[loop].plArr.updateEmbeddedEntity("PlaylistSound", {_id: chart[loop].sound._id, repeat: true});
          } else 
          if (chart[loop]._loop == true) {
                chart[loop]._loop = false;
                document.getElementById('loop_'+loop).style.backgroundColor = toggleOff;
                chart[loop].plArr.updateEmbeddedEntity("PlaylistSound", {_id: chart[loop].sound._id, repeat: false});
          }
    console.log(loop + ' : loop = ' + chart[loop]._loop)
    }
    
    function playFunction(play) {
          if (chart[play]._play == false) {
                chart[play]._play = true;
                document.getElementById('play_'+play).style.backgroundColor = toggleOn;
          } else
        {
                chart[play]._play = false;
                document.getElementById('play_'+play).style.backgroundColor = toggleOff;
          }
    console.log(play + ' : play = ' + chart[play]._play)
    }
    async function trChange(b) {
    //console.log('trChange: '+b);
    if (b == 'selected') {
    var y = document.getElementById("trSelect").value;
    } else {
    var y = b;
    }
    var x = document.getElementById("plSelect").value;
    //console.log(chart[y]);
    chart[y].inTheMix = true;
    thisid = 'id_' + y;
    if (chart[y].playing == true) {var backgroundColor = 'rgb(0,180,0,.3)'} else {var backgroundColor = 'rgb(255,255,255,.5)'};
    if (chart[y]._mute == true) {muteToggle = toggleOn} else {muteToggle = toggleOff};
    if (chart[y]._loop == true) {loopToggle = toggleOn} else {loopToggle = toggleOff};
    if (chart[y]._play == true) {playToggle = toggleOn} else {playToggle = toggleOff};
    var tag = '<div id="' + y + '" style="position: relative; height: 26px;"><div style="position: absolute; border-style: solid; border-width: 1px; top: 1px; width: 100%; height: 27px; background-color: ' + backgroundColor +';"></div>'+
    '<div style="position: absolute; border-style: solid; border-width: 0px; top: 3px; margin-bottom: 2px; width: 260px; padding-right: 0px; overflow: hidden; white-space: nowrap; display: inline-block; text-overflow: ellipsis; height: 26px;">'+
    '<div onclick="removeFunction('+ y +')" style="position: absolute;  top: 4px; left: 6px; height: 16px; width: 18px; line-height: 13px; text-align:center; font-size: 11px; border-radius: 8px; border-style: solid; border-width: 1px;"">x</div>'+
    '<div style="position: absolute; left: 30px; top: 3px;">' + decodeURIComponent(chart[y].name) +'</div>'+
    '</div>'+
    '<div id="mute_' + y + '" onclick="muteFunction('+ y +')" style="position: absolute;  top: 4px; right: 2px; height: 21px; width: 30px; line-height: 20px; text-align:center; font-size: 10px; background-color: ' + muteToggle + '; border-radius: 8px; border-style: solid; border-width: 1px;"">mute</div>'+
    '<div id="loop_' + y + '" onclick="loopFunction('+ y +')" style="position: absolute;  top: 4px; right: 33px; height: 21px; width: 30px; line-height: 20px; text-align:center; font-size: 10px; background-color: ' + loopToggle + '; border-radius: 8px; border-style: solid; border-width: 1px;">loop</div>'+
    '<div id="play_' + y + '" onclick="playFunction('+ y +')" style="position: absolute;  top: 4px; right: 64px; height: 21px; width: 30px; line-height: 20px; text-align:center; font-size: 10px; background-color: ' + playToggle + '; border-radius: 8px; border-style: solid; border-width: 1px;">play</div>'+
    '</div>';
    //
    var old = document.getElementById("billboard").innerHTML;
    document.getElementById("billboard").innerHTML = old+tag;
    //
    plChange();
    }
    for (var g = 0; g < chart.length; g++){
    if (chart[g].inTheMix == true) {
    trChange(g);
    }
    }
    </script>
    `;
    let dndjDialogList = new Dialog({
     title: `DnDj v.1 - SELECT`,
     content: `${CSSstr} ${html}`
      ,
    buttons: { 
        one: {
        icon: "",
        label: `cancel`,
        callback: html => {
    return;
    }
      },
        two: {
        icon: "",
        label: `MIXER`,
      callback: html => {   if (chart.filter(pl => pl.inTheMix).length ==  0) {
                                console.log('no tracks selected'); ui.notifications.warn(`*~* there's nothing to mix *~*`); theList(true);
                            } else {
                                var start = chart.filter(pl => pl.inTheMix == true && pl._play == true);
                                //console.log(start);
                                if (start.length != 0) {
                                    for (let s=0; s < start.length; s++) {
                                       start[s].plArr.updateEmbeddedEntity("PlaylistSound", {_id: start[s].sound._id, playing: true})
                                    }
                                } 
                                var mute = chart.filter(pl => pl.inTheMix == true && pl._mute == true);
                                //console.log(mute);
                                if (mute.length != 0) {
                                    for (let t=0; t < mute.length; t++) {
                                        mute[t].plArr.updateEmbeddedEntity("PlaylistSound", {_id: mute[t].sound._id, volume: 0})
                                    }
                                }
                                var remove = chart.filter(pl => pl.inTheMix == false && pl.playing == true);
                                //console.log(remove);
                                if (remove.length != 0) {
                                for (let t=0; t < mute.length; t++) {
                                    remove[t].plArr.updateEmbeddedEntity("PlaylistSound", {_id: remove[t].sound._id, playing: false})
                                    }
                                }
                                var stop = chart.filter(pl => pl._play == false && pl.playing == true);
                                //console.log(stop);
                                if (stop.length != 0) {
                                    for (let t=0; t < stop.length; t++) {
                                        stop[t].plArr.updateEmbeddedEntity("PlaylistSound", {_id: stop[t].sound._id, playing: false})
                                    }
                                }
                                theMixer(chart.filter(pl => pl.inTheMix == true));
                            }
                        }
                    },
                }
            });
    
    dndjDialogList.render(true);
    }
    theList(true);