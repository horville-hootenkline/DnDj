import {debug, report} from './engineer.js';
import * as producer from './producer.js';

//--//--//--//--//--//--//--//--//--//--//--//--//
// !--   brute force playing now function   --! //
//--//--//--//--//--//--//--//--//--//--//--//--//
//
export function bruteForcePlayingNow() {
    var playingArr = [];
    var _playing = Object.values(game.audio.sounds).filter(v => v.howl.playing() == true);
    for (const sound of _playing) {
        playingArr.push(sound.howl._src);
    }
    //console.log(playingArr);
    game.socket.emit("module.DnDj", {
        type: 'playingArr',
        who: 'all',
        state: playingArr,
    });
}

//--//--//--//--//--//--//--//--//
// !--   hey you function   --! //
//--//--//--//--//--//--//--//--//
//
export function heyYou(who, start) {
    game.socket.emit("module.DnDj", {type: 'invisibleTouch', who: who, state: game.settings.get("DnDj", "isLaunch")});
    var inTheMix = game.dndj.chart.filter(mf => mf.inTheMix == true);
    for (const chartEntry of inTheMix) {
        var startStates = ({
            playing:chartEntry.playing,
            pause: chartEntry.paused,
            mute: chartEntry.mute,
            loop: chartEntry.loop,
            elapsed: chartEntry.wolves.howl._sounds[0]._node.currentTime
        });
        if (start) {
            signal('start', chartEntry, startStates, who);
            //
            } else {
            //
            signal('pause', chartEntry, chartEntry.paused, who);
            signal('mute', chartEntry, chartEntry.mute, who);
            signal('loop', chartEntry, chartEntry.loop, who);
            signal('elapsed', chartEntry, chartEntry.wolves.howl._sounds[0]._node.currentTime, who);
            signal('volume', chartEntry, null, who);
        }
    }
    return;
}

//--//--//--//--//--//--//--//--//
// !--    signal function   --! //
//--//--//--//--//--//--//--//--//
//
export function signal(type, chartEntry, state, who) {
    var ping = new Date();
    var vol = chartEntry.volumeVol * game.dndj.volumes.maVolume;
    game.socket.emit("module.DnDj", {
        ping: ping.getTime(),
        type: type,
        who: who,
        id: chartEntry.sound._id,
        path: chartEntry.path,
        state: state,
        playing: chartEntry.playing,
        volume: vol,
    });
}

//--//--//--//--//--//--//--//--//--//--//
// !--   listener report function   --! //
//--//--//--//--//--//--//--//--//--//--//
//
function listenerReport(data, _funct) {
    var ping = new Date();
    var reportTime = ping.getHours().toString().padStart(2, "0") + ':'
        + ping.getMinutes().toString().padStart(2, "0") + ':'
        + ping.getSeconds().toString().padStart(2, "0") + '.'
        + ping.getMilliseconds().toString().padStart(3, "0");
    var detail = data.type + ' | ' + data.state;
    if (data.type == 'volume') {
        detail = data.type + ' | ' + data.volume.toFixed(3);
    } else if (data.type == 'start') {
        detail = data.path;
    }
    var pong = ((ping.getTime() - data.ping)/1000).toString().substring(1);
    var report = '((' + _funct + ')) ' + reportTime + ' | ' + pong + ' | ' + data.who + ' | ' + detail;
    return report
}

//--//--//--//--//--//--//--//--//
// !--   shut it function   --! //
//--//--//--//--//--//--//--//--//
//
function shutIt() {
    var noise = Object.values(game.audio.sounds).filter(v => v.howl.playing() == true);
    for (const sound of noise) {
        sound.howl.stop();
    }
}

//--//--//--//--//--//--//--//--//--//--//
// !--   invisible touch function   --! //
//--//--//--//--//--//--//--//--//--//--//
//
function invisibleTouch(state) {
    //console.log('invisble')
    if (!state) {
        if (game.settings.get("DnDj", "gpvHide")) {
            $('input[name="globalPlaylistVolume"]').parent().hide()
            }
        $('input[name="paSlider"]').parent().show();
    } else {
        $('input[name="globalPlaylistVolume"]').parent().show()
        $('input[name="paSlider"]').parent().hide();
    }
}

//--//--//--//--//--//--//
// !--  ready hook  --! //
//--//--//--//--//--//--//
//
Hooks.once("ready", () => {
    var pettibone = 'DnDj listener';
    console.log(report(pettibone,''));
    //
    game.socket.on("module.DnDj", data => {
        socketResponse(data)
    })
    if (!game.user.isGM) {
        producer.set_isLaunch(game.settings.get("DnDj", "isLaunch"));
        //var state = game.settings.get("DnDj", "isLaunch");
        invisibleTouch(producer._isLaunch)
        if (!producer._isLaunch) {
            shutIt();
            var ping = new Date();
            setTimeout(async function() {
                game.socket.emit("module.DnDj", {ping: ping.getTime(), type: 'is anybody out there?', who: game.user.name
            });},1000);
        }
    }
});

//--//--//--//--//--//--//--//--//--//--//
// !--   broadcast house function   --! //
//--//--//--//--//--//--//--//--//--//--//
//
async function broadcastHouse(id, volume, path, playing) {
    if (id != 'master') {
        if (!(game.dndjRadio.broadcast.some(cr => cr.id == id))) { 
            game.dndjRadio.broadcast.push({
                id: id,
                volume: volume,
                path: path,
                sound: game.audio.sounds[path].howl
            })
            if (debug(2)){
                var pettibone = 'BH';
                var _ids = [];
                for (const entry of game.dndjRadio.broadcast) {
                    _ids.push(entry.id)
                }
                console.log(report(pettibone, _ids.toString())); 
            }
        } else {
            game.dndjRadio.broadcast.find(w => w.id == id).volume = volume;
        }  
    }  
}

//--//--//--//--//--//--//--//--//--//--//
// !--   socket response function   --! //
//--//--//--//--//--//--//--//--//--//--//
//
function socketResponse(data) {
    var pettibone = 'socket';
    
    //--//--//--//--//--//--//--//
    // !--   GM response    --! //
    //--//--//--//--//--//--//--//
    //
    if (data.type == 'is anybody out there?') {
        console.log('((heyYou)) ' + data.who);
        heyYou(data.who, true);
        return
    }

    //--//--//--//--//--//--//--//--//
    // !--   PLAYER responses   --! //
    //--//--//--//--//--//--//--//--//
    //
    if (data.who == game.user.name || data.who == 'all') {

        if (data.type == 'invisibleTouch') {
            invisibleTouch(data.state);
            return
        }

        if (data.type == 'shutit') {
            shutIt()
            return
        }
        //
        if (data.type == 'playingArr') {
            console.log('playingArr')
            var playingArr = data.state
            game.dndjRadio.status.playArray = playingArr;
            var allSounds = Object.values(game.audio.sounds);
            for (const sound of allSounds) {
                if (playingArr.includes(sound.howl._src) && !sound.howl.playing()) {
                    sound.howl.play();
                } else if (!playingArr.includes(sound.howl._src) && sound.howl.playing()) {
                    sound.howl.stop();
                }
            }
            return
        }

        //--//--//--//--//--//--//--//--//--//--//--//
        // !--    start once playing function   --! //
        //--//--//--//--//--//--//--//--//--//--//--//
        //
        // starting a track and syncing it with the GM
        //
        function startOncePlaying(data) {
            broadcastHouse(data.id, data.volume, data.path, data.playing);
            var now = new Date(); var pong = (now.getTime() - data.ping)/1000;
            //
            game.audio.sounds[data.path].starter = true;
            // elapsed
            game.audio.sounds[data.path].howl.seek((data.state.elapsed)+pong);
            // pause
            if (data.state.pause) {
                game.audio.sounds[data.path].howl.pause();
            }
            // volume
            game.audio.sounds[data.path].howl.volume(data.volume * game.dndjRadio.volumes.paVolume);
            // mute
            game.audio.sounds[data.path].howl.mute(data.state.mute);
            // loop
            game.audio.sounds[data.path].howl.loop(data.state.loop);
            //
            if (!data.state.mute) {
                if (game.audio.sounds[data.path].howl.mute()) {
                    game.audio.sounds[data.path].howl.volume(data.volume * game.dndjRadio.volumes.paVolume);
                }
            }
            return;
        }
        //
        // startOncePlaying if loaded, or wait until loaded
        //
        if (data.type == 'start') { 
            if (data.playing) {
                game.audio.sounds[data.path].howl.play();
            } else {
                if (game.audio.sounds[data.path].howl._state != 'loaded') {
                    game.audio.sounds[data.path].howl.load();
                }
            }
            if (game.audio.sounds[data.path].howl._state == 'loaded') {
                if (debug(1)){console.log(listenerReport(data, 'S_loaded'))};
                if (debug(2)){console.log(report('S_loaded', data.state))};
                startOncePlaying(data);

            } else {
                game.audio.sounds[data.path].howl.once('load', function() {
                    if (debug(1)){console.log(listenerReport(data, 'S_onload'))};
                    if (debug(2)){console.log(report('S_onload', data.state))};
                    startOncePlaying(data);
                }) 
            }
        } else {
            //
            //--//--//--//--//--//--//--//--//--//
            // !--   once loaded function   --! //
            //--//--//--//--//--//--//--//--//--//
            //
            // changes made to a track once running (if the howl instance is loaded, or waiting for it to load)
            //
            async function onceLoaded(data) {
                var now = new Date(); var pong = (now.getTime() - data.ping)/1000;
                var soundEntry = game.audio.sounds[data.path].howl._sounds.length-1;
                broadcastHouse(data.id, data.volume, data.path, data.playing)
                //
                if (data.type == 'play') {
                    if (data.state) {
                        if (game.audio.sounds[data.path].howl._sounds[soundEntry]._paused) {
                            game.audio.sounds[data.path].howl.play();
                            game.audio.sounds[data.path].howl.volume(data.volume * game.dndjRadio.volumes.paVolume);
                        }
                    }
                    if (!data.state) {
                        if (!game.audio.sounds[data.path].howl._sounds[soundEntry]._paused) {
                            game.audio.sounds[data.path].howl.pause()
                        }
                    }
                    return
                }
                //
                if (data.type == 'stop') {
                    game.audio.sounds[data.path].howl.stop();

                }
                //
                if (data.type == 'pause') { 
                    game.audio.sounds[data.path].howl.volume(0);   
                    if (data.state) {
                            if (!game.audio.sounds[data.path].howl._sounds[soundEntry]._paused) {
                                game.audio.sounds[data.path].howl.pause();
                            }
                    }
                    if (!data.state) {
                        if (game.audio.sounds[data.path].howl._sounds[soundEntry]._paused) {
                            game.audio.sounds[data.path].howl.volume(data.volume * game.dndjRadio.volumes.paVolume);
                            game.audio.sounds[data.path].howl.play();
                        }
                    }
                    return
                }
                //
                if (data.type == 'mute') {
                    if (data.state) {
                        if (!game.audio.sounds[data.path].howl.mute()) {
                            game.audio.sounds[data.path].howl.mute(true);
                        }
                    }
                    if (!data.state) {
                        if (game.audio.sounds[data.path].howl.mute()) {
                            game.audio.sounds[data.path].howl.volume(data.volume * game.dndjRadio.volumes.paVolume);
                            game.audio.sounds[data.path].howl.mute(false);
                        }
                    }
                    return
                }
                //
                if (data.type == 'volume') { 
                    game.audio.sounds[data.path].howl.volume(data.volume * game.dndjRadio.volumes.paVolume)
                    return
                }
                //
                if (data.type == 'loop') {
                    game.audio.sounds[data.path].howl.loop(data.state);
                    return
                }
                //
                if (data.type == 'elapsed') {
                    game.audio.sounds[data.path].howl.seek((data.state)+pong);
                    return
                }
                //
            }
            if (game.audio.sounds[data.path].loaded) {
                if (debug(1)){console.log(listenerReport(data, '*_loaded'))};
                if (debug(2)){console.log(report('*_loaded', data))};
                onceLoaded(data)
                return
            }
            game.audio.sounds[data.path].howl.once('load', function() {
                if (debug(1)){console.log(listenerReport(data, '*_onload'))};
                if (debug(2)){console.log(report('*_onload', data))};
                onceLoaded(data)
            })   
        }
    }
}